# Aggregate reference outputs

These files are included to make result checking easier without distributing participant-level predictions or fitted MCMC objects.

- `pbc2_full_data_posterior_summary.csv` combines the full-data posterior summaries for both biomarkers, three association structures, and three quantiles.
- `pbc2_cv5_dynamic_prediction_summary.csv` contains the pooled five-fold AUC and IPCW Brier summaries and fold-to-fold standard deviations.

The prediction summary reproduces the values displayed in the two dissertation prediction tables. The full-data source summaries are numerically consistent with the posterior tables; a small number of displayed entries differ in the final reported decimal (approximately 0.001), reflecting historical table preparation or rounding. The source-precision values are retained here rather than silently replacing them with values copied from the dissertation.

No source PBC2 rows, subject identifiers, individual predictions, or posterior draws are included.
