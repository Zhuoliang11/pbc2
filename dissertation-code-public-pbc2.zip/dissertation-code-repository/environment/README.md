# Software requirements

No historical `sessionInfo()` was identified in the retained PBC2 materials. Exact package versions are therefore not claimed.

The supplied workflows require:

- R;
- JAGS;
- a working C++ toolchain;
- `MASS`, `survival`, `rjags`, `coda`, `doParallel`, `foreach`, `doRNG`, `GIGrvg`, `Rcpp`, `nlme`, `caret`, `dplyr`, `pROC`, `JM`, `tidyr`, `ggplot2`, `timeROC`, `survminer`, `rmarkdown`, and `knitr`.

Install JAGS separately, then install the required R packages before running the workflows. Save `sessionInfo()` and `rjags::jags.version()` with any new reproduction attempt.
