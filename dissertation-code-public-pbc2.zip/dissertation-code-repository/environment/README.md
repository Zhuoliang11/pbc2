# Reference software environment

The following versions were installed in the environment used to prepare and inspect this archive on 11 September 2026. The exact original PBC2 run environment was not saved, so these versions are a compatible reference rather than a historical provenance claim.

- R 4.5.2
- JAGS 4.3.2
- MASS 7.3-66
- survival 3.8-9
- rjags 4-17
- coda 0.19-4.1
- doParallel 1.0.17
- foreach 1.5.2
- doRNG 1.8.6.3
- GIGrvg 0.8
- Rcpp 1.1.2
- nlme 3.1-170
- caret 7.0-1
- dplyr 1.2.1
- pROC 1.19.0.1
- JM 1.5-2
- tidyr 1.3.1
- ggplot2 4.0.0
- timeROC 0.4.1
- survminer 0.5.2
- rmarkdown 2.30
- knitr 1.50

Install JAGS separately, then install the required R packages before running the workflows. Save `sessionInfo()` with any new reproduction attempt so differences from this reference environment can be diagnosed.
