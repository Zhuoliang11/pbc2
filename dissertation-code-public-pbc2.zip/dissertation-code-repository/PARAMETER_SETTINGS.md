# Formal parameter settings

All workflows use random seed 2026 where a seed is set in the supplied code and evaluate quantiles 0.25, 0.50, and 0.75. The formal scripts use two JAGS chains.

## Simulation study

Common settings are 500 participants, 100 replications, target censoring of 50%, and prediction windows `(0.75, 1.50)`, `(1.00, 1.75)`, and `(1.50, 2.00)`.

| Association | Adaptation | Burn-in | Sampling iterations | Thinning |
|---|---:|---:|---:|---:|
| Shared random effects | 30,000 | 60,000 | 50,000 | 100 |
| Current value | 10,000 | 20,000 | 10,000 | 50 |
| Composite | 15,000 | 50,000 | 75,000 | 150 |

The simulation prediction routine uses 200 outer posterior draws, 100 retained subject-specific draws, and 50 burn-in draws.

## PBC2 full-data application

| Association | Adaptation | Burn-in | Sampling iterations | Thinning |
|---|---:|---:|---:|---:|
| Shared random effects | 30,000 | 100,000 | 200,000 | 400 |
| Current value | 50,000 | 100,000 | 200,000 | 400 |
| Composite | 30,000 | 100,000 | 200,000 | 400 |

## PBC2 five-fold application

The folds are stratified by the event indicator with seed 2026. All three associations and both biomarkers use:

- 5 folds;
- 15,000 adaptation iterations;
- 80,000 burn-in iterations;
- 150,000 sampling iterations;
- thinning interval 260;
- prediction windows `(2, 4)`, `(4, 6)`, and `(6, 8)` years;
- 200 outer posterior draws, 100 retained subject-specific draws, and 50 burn-in draws for dynamic prediction.

These values document the scripts supplied with the dissertation and should not be silently replaced by shorter settings when reproducing the reported results.
