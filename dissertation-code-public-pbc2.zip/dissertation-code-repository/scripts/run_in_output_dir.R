args <- commandArgs(trailingOnly = TRUE)

if (length(args) != 2L) {
  stop(
    "Usage: Rscript scripts/run_in_output_dir.R <analysis-script> <output-directory>",
    call. = FALSE
  )
}

file_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(file_arg) != 1L) {
  stop("Could not determine the launcher location.", call. = FALSE)
}

launcher <- normalizePath(sub("^--file=", "", file_arg), mustWork = TRUE)
repo_root <- normalizePath(file.path(dirname(launcher), ".."), mustWork = TRUE)
analysis_script <- normalizePath(file.path(repo_root, args[1]), mustWork = TRUE)

if (!startsWith(analysis_script, paste0(repo_root, .Platform$file.sep))) {
  stop("The analysis script must be located inside this repository.", call. = FALSE)
}

output_dir <- if (grepl("^(/|[A-Za-z]:)", args[2])) {
  args[2]
} else {
  file.path(repo_root, args[2])
}
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
output_dir <- normalizePath(output_dir, mustWork = TRUE)

# Some original scripts write their JAGS program at run time, whereas others
# read a supplied JAGS file. Copying the small model files makes both styles
# work from a clean output directory without changing the analysis code.
jags_files <- list.files(
  file.path(repo_root, "jags"),
  pattern = "[.]jags$",
  full.names = TRUE
)
if (length(jags_files)) {
  file.copy(jags_files, output_dir, overwrite = TRUE)
}

message("Repository: ", repo_root)
message("Analysis script: ", analysis_script)
message("Output directory: ", output_dir)

old_wd <- setwd(output_dir)
on.exit(setwd(old_wd), add = TRUE)
source(analysis_script, chdir = FALSE, echo = FALSE)
