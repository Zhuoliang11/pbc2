# Expected outputs

Generated results are intentionally excluded from version control.

## Simulation

| Script | Main output pattern |
|---|---|
| `my_sim_shared.R` | `share_effect_random_sim_results_tau_0.25.RData` (and 0.50, 0.75) |
| `run_sim_all_current.R` | `current_value_random_pred_100_multi_window_0.25.RData` (and 0.50, 0.75) |
| `jifen_tau_025.R` | `composite_results_tau_25.RData` |
| `jifen_tau_050.R` | `composite_results_tau_50.RData` |
| `jifen_tau_075.R` | `composite_results_tau_75.RData` |

The simulation `.RData` files contain parameter summaries, censoring summaries, prediction metrics, and generated data objects used by `simulation_summary.Rmd`.

## Full-data PBC2 fits

Each script creates one `.RData` file per quantile under its selected output directory. The bilirubin patterns are:

- `pbc2_shared_re_bili_tau_*.RData`;
- `pbc2_current_re_bili_tau_*.RData`;
- `pbc2_composite_re_bili_tau_*.RData`.

The albumin patterns replace `bili` with `albumin`. These files contain the fitted MCMC objects and summaries read by `nofold_comparison.Rmd`.

## Five-fold PBC2 fits

The main patterns are:

- `pbc2_shared_re_{bili,albumin}_tau_*.RData`;
- `pbc2_current_value_{bili,albumin}_tau_*.RData`;
- `pbc2_composite_{bili,albumin}_tau_*.RData`.

They contain fold-level estimates, predictions, metrics, convergence summaries, and posterior objects used by `dissertation_validation.Rmd`.

## Post-processing

The R Markdown files render HTML summaries and may write CSV or text tables beside the result objects. The rendered documents and tables are the appropriate items to compare with the dissertation; the large MCMC objects are intermediate computational artifacts.

## Bundled verification summaries

- `reference_outputs/pbc2_cv5_dynamic_prediction_summary.csv` corresponds to the two five-fold PBC2 prediction tables.

These files contain aggregate values only and are intentionally tracked despite the general CSV ignore rule. See `RESULTS_MAP.md` for the exact dissertation labels and script mapping.
