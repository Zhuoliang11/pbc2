
# 加载必要库
library(survival)
library(rjags)
library(JM) 
library(dplyr)
library(nlme)
library(parallel) # 🟢 修复：显式引入以确保本地环境 detectCores() 可用

load.module("glm")

# ========================================================
# 1. 动态生成 JAGS 模型文件 (SRE)
# ========================================================
cat("model {
   # 1. 预先计算 ALD 分布的相关常数
   k1 <- (1 - 2 * tau_quant) / (tau_quant * (1 - tau_quant))
   k2 <- sqrt(2 / (tau_quant * (1 - tau_quant)))

   # 定义随机效应的均值向量
   mu.b[1] <- 0
   mu.b[2] <- 0

   # 2. 核心数据循环
   for (i in 1:N_subj) {
     
     # 随机截距和随机斜率
     b[i, 1:2] ~ dmnorm(mu.b[1:2], D_inv[1:2, 1:2])
     
     # 【纵向子模型】
     for (j in 1:num_meas[i]) {
       e[i, j] ~ dexp(1 / sigma)
       mu[i, j] <- beta[1] + beta[2]*age[i] +beta[3]*time[i, j] + 
                   b[i, 1] + b[i, 2]*time[i, j] + k1 * e[i, j]
       
       prec_Y[i, j] <- 1 / max(k2 * k2 * sigma * e[i, j], 1e-5)
       Y[i, j] ~ dnorm(mu[i, j], prec_Y[i, j])
     }
     
     # 【生存子模型 - 共享随机效应】
     eta_surv[i] <- gamma[1]*age[i]  + alpha[1]*b[i, 1] + alpha[2]*b[i, 2]
   
     # Weibull 风险函数 & 累积风险
     hazard[i] <- lambda * gamma_shape * pow(max(years[i], 1e-5), gamma_shape - 1) * exp(eta_surv[i])
     cum_hazard[i] <- lambda * pow(years[i], gamma_shape) * exp(eta_surv[i])
     
     # 似然函数 (Zeros Trick)
     logL[i] <- delta[i] * log(max(1e-10, hazard[i])) - cum_hazard[i]
     phi[i] <- -logL[i] + 100000
     zeros[i] ~ dpois(phi[i])
   }

   for (p in 1:3) { beta[p] ~ dnorm(0, 0.01) }
   for (q in 1:1) { gamma[q] ~ dnorm(0, 0.01) } 
   for (a in 1:2) { alpha[a] ~ dnorm(0, 0.01) } 
   
   tau.sigma ~ dgamma(0.01, 0.01)
   sigma <- 1 / tau.sigma 
   
   log_lambda ~ dnorm(0, 0.01) 
   lambda <- exp(log_lambda)
   
   gamma_shape ~ dunif(0.1, 5) 

   D_inv[1:2, 1:2] ~ dwish(R.mat[1:2, 1:2], k.wishart)
   D[1:2, 1:2] <- inverse(D_inv[,])
 }
 ", file = "jm_ald_weibull_pbc2_shared.jags")

# ========================================================
# 2. 真实数据准备 (100%全数据，无 K-Fold)
# ========================================================
data(pbc2)
data(pbc2.id)

df_surv_real <- pbc2.id %>%
   mutate(event = status2) %>%
   dplyr::select(id, years, event, age)

df_long_real <- pbc2 %>%
   mutate(time = year, Y = log(albumin)) %>%
   dplyr::select(id, time, Y) %>%
   filter(!is.na(Y))

# 全局年龄标准化
train_age_mean <- mean(df_surv_real$age, na.rm = TRUE)
train_age_sd   <- sd(df_surv_real$age, na.rm = TRUE)
df_surv_real$age_z <- (df_surv_real$age - train_age_mean) / train_age_sd
df_long_real$age_z <- df_surv_real$age_z[match(df_long_real$id, df_surv_real$id)]

# JAGS ID 对齐
df_surv_real$id_jags <- 1:nrow(df_surv_real)
df_long_real$id_jags <- match(df_long_real$id, df_surv_real$id)
n_train <- nrow(df_surv_real)

# 构建 JAGS 输入矩阵
num_meas_train <- as.numeric(table(factor(df_long_real$id_jags, levels = 1:n_train)))
Y_mat <- matrix(NA, n_train, max(num_meas_train))
time_mat <- matrix(0, n_train, max(num_meas_train)) 

for(i in 1:n_train) {
   idx <- which(df_long_real$id_jags == i)
   if(length(idx) > 0){
      Y_mat[i, 1:length(idx)] <- df_long_real$Y[idx]
      time_mat[i, 1:length(idx)] <- df_long_real$time[idx] 
   }
}

R_mat_adjusted <- matrix(c(1, 0, 0, 0.1), 2, 2)
slurm_cores <- as.numeric(Sys.getenv("SLURM_NTASKS"))
if (is.na(slurm_cores)) slurm_cores <- min(5, parallel::detectCores() - 1) # 🟢 修复：指定命名空间

# ========================================================
# 3. 初始值生成 (Initial Values)
# ========================================================
fit_lme <- try(nlme::lme(Y ~ age_z + time, random = ~ time | id_jags, data = df_long_real, control = nlme::lmeControl(opt = "optim")), silent = TRUE)
init_beta <- if(!inherits(fit_lme, "try-error")) as.numeric(nlme::fixef(fit_lme)) else rnorm(3, 0, 0.1)

fit_surv <- try(survival::survreg(Surv(years, event) ~ age_z, data = df_surv_real, dist = "weibull"), silent = TRUE)
if(!inherits(fit_surv, "try-error")) {
   init_gamma <- -as.numeric(coef(fit_surv)[2]) / fit_surv$scale
   init_rho <- 1 / fit_surv$scale
   init_log_lam <- -as.numeric(coef(fit_surv)[1]) / fit_surv$scale
} else {
   init_gamma <- rnorm(1, 0, 0.1); init_rho <- 1.0; init_log_lam <- log(0.01)
}

inits_func <- function(chain_id) {
                 list(
                   beta = as.numeric(init_beta) + rnorm(3, 0, 0.01),
                   gamma = as.numeric(init_gamma) + rnorm(1, 0, 0.02),
                   alpha = c(runif(1, 0.1, 0.5), rnorm(1, 0, 0.1)),
                   log_lambda = init_log_lam + rnorm(1, 0, 0.05), 
                   gamma_shape = init_rho * exp(rnorm(1, 0, 0.02))
                 )
               }
inits_list <- list(inits_func(1), inits_func(2))

# ========================================================
# 4. 执行全数据拟合主循环 (遍历 Tau)
# ========================================================
tau_values <- c(0.25, 0.50, 0.75)
final_results_list <- list()
target_P <- 1000       # 🟢 修复1：明确定义抽取的目标后验样本数
start_time <- Sys.time() # 🟢 修复2：初始化全局计算起始时间

for (current_tau in tau_values) {
   cat(sprintf("\n\n>>> 开始执行全局数据集拟合: Tau = %.2f\n", current_tau))
   
   # 🟢 修复5：精简数据输入，移除未使用的 GK.nodes 和 GK.weights 清理警告
   jags_data_full <- list(
     N_subj = n_train, num_meas = num_meas_train, Y = Y_mat, time = time_mat,
     years = df_surv_real$years, delta = df_surv_real$event, 
     age = df_surv_real$age_z, tau_quant = current_tau, 
     R.mat = R_mat_adjusted, k.wishart = 3, zeros = rep(0, n_train)
   )
   
   # 【重火力 MCMC 配置】
   cat("阶段1: 适应 (Adaptation) 30000 次...\n")
   m <- jags.model("jm_ald_weibull_pbc2_shared.jags", data = jags_data_full, inits = inits_list, n.chains = 2, n.adapt = 30000, quiet = FALSE)
   
   cat("阶段2: 预热 (Burn-in) 100000 次...\n")
   update(m, 100000, progress.bar = "text") 
   
   cat("阶段3: 监控 (Sampling) 200000 次，细化间隔 400...\n")
   var_names_to_monitor <-  c("beta", "gamma", "alpha", "sigma", "lambda", "gamma_shape") 
   samples <- coda.samples(m, variable.names = var_names_to_monitor, n.iter = 200000, thin = 400)
   
   # ----------------------------------------------------
   # 🟢 【精确对齐你的保存逻辑】：构建单次运行的输出载体
   # ----------------------------------------------------
   summ <- summary(samples)
   rhat <- tryCatch(gelman.diag(samples, multivariate = FALSE)$psrf[, 1], error = function(e) rep(NA, nrow(summ$statistics)))
   
   post_mat_full <- as.matrix(samples) 
   actual_P <- min(nrow(post_mat_full), target_P) 
   post_mat <- post_mat_full[sample(1:nrow(post_mat_full), actual_P), ]
   
   # 转换单折简表用于标准输出监控
   estimates_summary <- data.frame(
     param = rownames(summ$statistics), 
     mean = summ$statistics[,"Mean"], 
     sd = summ$statistics[,"SD"]
   )
   rhat_summary <- data.frame(
     param = names(rhat), 
     rhat = rhat
   )
   
   # 打印在 CSF 的标准输出中
   cat(sprintf("\n[Results] PBC2 Parameter Evaluation (Tau = %.2f)\n", current_tau))
   print(estimates_summary, digits = 4)
   
   run_time <- Sys.time() - start_time
   
   # 按照你给的完全一致的结构打包变量名
   cv_results <- list(
     list(
       samples = samples,
       post_mat = post_mat_full,
       estimates = estimates_summary,
       rhat = rhat_summary
     )
   )
   all_rhat <- rhat_summary
   all_samples_list <- list(samples)
   all_post_mats <- list(post_mat_full)
   
   # 🟢 修复3：移除错误的 %s 占位符，保证文件名动态生成正确
   rdata_filename <- sprintf("pbc2_shared_re_albumin_tau_%.2f.RData", current_tau)
   
   # 完美对齐你的 save() 列表命名
   save(cv_results, all_rhat, all_samples_list, all_post_mats, run_time, file = rdata_filename)
   cat(sprintf("[Output] Results successfully saved to %s\n", rdata_filename))
}