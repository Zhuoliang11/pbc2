# 加载必要库
library(survival)
library(rjags)
library(JM) 
library(dplyr)
library(nlme)
library(parallel) # 🟢 引入：确保本地与集群环境 detectCores() 可用

load.module("glm")

# ========================================================
# 1. 动态生成 JAGS 模型文件 (Composite Structure - 积分模型)
# ========================================================
cat("
  model {
    # 1. Longitudinal Part (使用中心化时间 time_c)
    prec_k2 <- (tau_quant * (1 - tau_quant)) / 2
    k1 <- (1 - 2 * tau_quant) / (tau_quant * (1 - tau_quant))
    
    for (i in 1:N_subj) {
      for (j in 1:num_meas[i]) {
        mu_long[i, j] <- beta[1] + beta[2]*age[i]  + beta[3]*time_c[i, j] + 
                         b[i, 1] + b[i, 2]*time_c[i, j]
        Y[i, j] ~ dnorm(mu_long[i, j] + k1 * e[i, j], prec_long[i, j])
        prec_long[i, j] <- prec_k2 / max(sigma * e[i, j], 1e-7)
        e[i, j] ~ dexp(1 / sigma)
      }
    }

    # 2. Survival Part - Composite Association (数值积分部分)
    for (i in 1:N_subj) {
      b[i, 1:2] ~ dmnorm(mu.b[1:2], D_inv[1:2, 1:2])
      
      mu_c[i] <- beta[1] + beta[2]*age[i] + b[i, 1]
      mu_1[i] <- beta[3] + b[i, 2]
      
      m_T[i] <- mu_c[i] + mu_1[i] * (years[i] - mean_time)
      m_prime_T[i] <- mu_1[i]
      m_int_T[i] <- mu_c[i] * years[i] + mu_1[i] * (0.5 * pow(years[i], 2) - mean_time * years[i])
      
      assoc_T[i] <- alpha[1]*m_T[i] + alpha[2]*m_prime_T[i] + alpha[3]*m_int_T[i]
      hazard[i] <- lambda * rho * pow(max(years[i], 1e-7), rho - 1) * exp(gamma_surv[1]*age[i]  + assoc_T[i])
      
      for (k in 1:7) {
        u[i, k] <- (years[i] / 2) * GK.nodes[k] + (years[i] / 2)
        
        m_u[i, k] <- mu_c[i] + mu_1[i] * (u[i, k] - mean_time)
        m_prime_u[i, k] <- mu_1[i]
        m_int_u[i, k] <- mu_c[i] * u[i, k] + mu_1[i] * (0.5 * pow(u[i, k], 2) - mean_time * u[i, k])
        
        assoc_u[i, k] <- alpha[1]*m_u[i, k] + alpha[2]*m_prime_u[i, k] + alpha[3]*m_int_u[i, k]
        h_u[i, k] <- lambda * rho * pow(max(u[i, k], 1e-7), rho - 1) * exp(gamma_surv[1]*age[i] +  assoc_u[i, k])
      }
      
      cum_hazard[i] <- (years[i] / 2) * inprod(GK.weights[1:7], h_u[i, 1:7])
      
      logL[i] <- delta[i] * log(max(1e-10, hazard[i])) - cum_hazard[i]
      phi[i] <- -logL[i] + 100000
      zeros[i] ~ dpois(phi[i])
    }

    # 3. Regularized Priors
    for (p in 1:3) { beta[p] ~ dnorm(0, 0.1) } 
    for (q in 1:1) { gamma_surv[q] ~ dnorm(0, 0.01) }
    for (a in 1:3) { alpha[a] ~ dnorm(0, 0.01) }

    tau.sigma ~ dgamma(0.01, 0.01)
    sigma <- 1 / tau.sigma 
    
    log_lambda ~ dnorm(0, 0.1)  
    lambda <- exp(log_lambda)
    rho ~ dunif(0.1, 5) 
    
    mu.b[1] <- 0; mu.b[2] <- 0
    D_inv[1:2, 1:2] ~ dwish(R.mat[1:2, 1:2], k.wishart)
    D[1:2, 1:2] <- inverse(D_inv[,])
  }
", file = "jm_composite_pbc2.jags")

# ========================================================
# 2. 真实数据准备 (100%全数据，无 K-Fold)
# ========================================================
data(pbc2)
data(pbc2.id)

df_surv_real <- pbc2.id %>%
  mutate(event = status2) %>%
  dplyr::select(id, years, event, age)

df_long_real <- pbc2 %>%
  mutate(time = year, Y = log(serBilir)) %>% # 🟢 如果你要换成albumin，可在此处修改
  dplyr::select(id, time, Y) %>%
  filter(!is.na(Y))

# 全局年龄标准化
train_age_mean <- mean(df_surv_real$age, na.rm = TRUE)
train_age_sd   <- sd(df_surv_real$age, na.rm = TRUE)
df_surv_real$age_z <- (df_surv_real$age - train_age_mean) / train_age_sd
df_long_real$age_z <- df_surv_real$age_z[match(df_long_real$id, df_surv_real$id)]

# 全局时间中心化
train_time_mean <- mean(df_long_real$time, na.rm = TRUE)
df_long_real$time_c <- df_long_real$time - train_time_mean

# JAGS ID 对齐
df_surv_real$id_jags <- 1:nrow(df_surv_real)
df_long_real$id_jags <- match(df_long_real$id, df_surv_real$id)
n_train <- nrow(df_surv_real)

# 构建 JAGS 输入矩阵
num_meas_train <- as.numeric(table(factor(df_long_real$id_jags, levels = 1:n_train)))
Y_mat <- matrix(NA, n_train, max(num_meas_train))
time_c_mat <- matrix(0, n_train, max(num_meas_train)) 

for(i in 1:n_train) {
  idx <- which(df_long_real$id_jags == i)
  if(length(idx) > 0){
    Y_mat[i, 1:length(idx)] <- df_long_real$Y[idx]
    time_c_mat[i, 1:length(idx)] <- df_long_real$time_c[idx] 
  }
}

GK.nodes <- c(-0.9491079, -0.7415312, -0.4058452, 0, 0.4058452, 0.7415312, 0.9491079)
GK.weights <- c(0.1294850, 0.2797054, 0.3818301, 0.4179592, 0.3818301, 0.2797054, 0.1294850)
R_mat_adjusted <- matrix(c(1, 0, 0, 0.1), 2, 2)

# 环境核心数自动检测
slurm_cores <- as.numeric(Sys.getenv("SLURM_NTASKS"))
if (is.na(slurm_cores)) slurm_cores <- min(5, parallel::detectCores() - 1)

# ========================================================
# 3. 初始值生成 (Initial Values)
# ========================================================
fit_lme <- try(nlme::lme(Y ~ age_z + time_c, random = ~ time_c | id_jags, data = df_long_real, control = nlme::lmeControl(opt = "optim")), silent = TRUE)
init_beta <- if(!inherits(fit_lme, "try-error")) as.numeric(nlme::fixef(fit_lme)) else rnorm(3, 0, 0.1)

fit_surv <- try(survival::survreg(Surv(years, event) ~ age_z, data = df_surv_real, dist = "weibull"), silent = TRUE)
if(!inherits(fit_surv, "try-error")) {
  init_gamma <- -as.numeric(coef(fit_surv)[2]) / fit_surv$scale
  init_rho <- 1 / fit_surv$scale
  init_log_lam <- -as.numeric(coef(fit_surv)[1]) / fit_surv$scale
} else {
  init_gamma <- rnorm(1, 0, 0.1); init_rho <- 1.0; init_log_lam <- log(0.01)
}

inits_func <- function(chain_id) {
  list(
    beta = as.numeric(init_beta) + rnorm(3, 0, 0.05),
    gamma_surv = as.numeric(init_gamma) + rnorm(1, 0, 0.05),
    alpha = c(runif(1, 0.1, 0.5), rnorm(2, 0, 0.1)), 
    log_lambda = init_log_lam + rnorm(1, 0, 0.05), 
    rho = init_rho * exp(rnorm(1, 0, 0.05))
  )
}
inits_list <- list(inits_func(1), inits_func(2))

# ========================================================
# 4. 执行全数据拟合主循环 (遍历 Tau)
# ========================================================
tau_values <- c(0.25, 0.50, 0.75)
final_results_list <- list()
target_P <- 1000         # 🟢 对齐：明确定义抽取的目标后验样本数
start_time <- Sys.time() # 🟢 对齐：初始化全局计算起始时间

for (current_tau in tau_values) {
  cat(sprintf("\n\n>>> 开始执行全局数据集拟合 (Composite 积分模型): Tau = %.2f\n", current_tau))
  
  jags_data_full <- list(
    N_subj = n_train, num_meas = num_meas_train, Y = Y_mat, time_c = time_c_mat,
    mean_time = train_time_mean, years = df_surv_real$years, delta = df_surv_real$event, 
    age = df_surv_real$age_z, tau_quant = current_tau, 
    R.mat = R_mat_adjusted, k.wishart = 3, zeros = rep(0, n_train),
    GK.nodes = GK.nodes, GK.weights = GK.weights
  )
  
  # 【重火力 MCMC 配置】
  cat("阶段1: 适应 (Adaptation) 30000 次...\n")
  m <- jags.model("jm_composite_pbc2.jags", data = jags_data_full, inits = inits_list, n.chains = 2, n.adapt = 30000, quiet = FALSE)
  
  cat("阶段2: 预热 (Burn-in) 100000 次...\n")
  update(m, 100000, progress.bar = "text") 
  
  cat("阶段3: 监控 (Sampling) 200000 次，细化间隔 400...\n")
  var_names_to_monitor <- c("beta", "gamma_surv", "alpha", "sigma", "lambda", "rho") 
  samples <- coda.samples(m, variable.names = var_names_to_monitor, n.iter = 200000, thin = 400)
  
  # ----------------------------------------------------
  # 🟢 【精确对齐你的保存逻辑】：构建完全一致的输出载体与结构
  # ----------------------------------------------------
  summ <- summary(samples)
  rhat <- tryCatch(gelman.diag(samples, multivariate = FALSE)$psrf[, 1], error = function(e) rep(NA, nrow(summ$statistics)))
  
  post_mat_full <- as.matrix(samples) 
  actual_P <- min(nrow(post_mat_full), target_P) 
  post_mat <- post_mat_full[sample(1:nrow(post_mat_full), actual_P), ]
  
  # 转换单折简表用于标准输出监控
  estimates_summary <- data.frame(
    param = rownames(summ$statistics), 
    mean = summ$statistics[,"Mean"], 
    sd = summ$statistics[,"SD"]
  )
  rhat_summary <- data.frame(
    param = names(rhat), 
    rhat = rhat
  )
  
  # 打印在标准输出中
  cat(sprintf("\n[Results] PBC2 Composite Parameter Evaluation (Tau = %.2f)\n", current_tau))
  print(estimates_summary, digits = 4)
  
  run_time <- Sys.time() - start_time
  
  # 🟢 完美对齐 shared 脚本的 save() 列表打包结构
  cv_results <- list(
    list(
      samples = samples,
      post_mat = post_mat_full,
      estimates = estimates_summary,
      rhat = rhat_summary
    )
  )
  all_rhat <- rhat_summary
  all_samples_list <- list(samples)
  all_post_mats <- list(post_mat_full)
  
  # 动态生成专属积分模型的文件名
  rdata_filename <- sprintf("pbc2_composite_re_bili_tau_%.2f.RData", current_tau)
  
  # 执行保存
  save(cv_results, all_rhat, all_samples_list, all_post_mats, run_time, file = rdata_filename)
  cat(sprintf("[Output] Results successfully saved to %s\n", rdata_filename))
}

cat("\n✅ 复合积分模型（Composite）全量数据拟合及对齐保存完毕！\n")