library(MASS)
library(survival)
library(rjags)
load.module("glm")
library(doParallel)
library(foreach)
library(doRNG)
library(GIGrvg)
library(Rcpp)
library(dplyr)
library(JM)     
library(pROC)   
library(nlme)
library(caret)

# ========================================================
# 1. 动态生成 JAGS 模型文件
# ========================================================
cat("
  model {
    # 1. Longitudinal Part - ALD Implementation
    prec_k2 <- (tau_quant * (1 - tau_quant)) / 2
    k1 <- (1 - 2 * tau_quant) / (tau_quant * (1 - tau_quant))
    
    for (i in 1:N_subj) {
      for (j in 1:num_meas[i]) {
        mu_long[i, j] <- beta[1] + beta[2]*age[i] + beta[3]*time[i, j] + 
                 b[i, 1] + b[i, 2]*time[i, j]
        Y[i, j] ~ dnorm(mu_long[i, j] + k1 * e[i, j], prec_long[i, j])
        prec_long[i, j] <- prec_k2 / max(sigma * e[i, j], 1e-7)
        e[i, j] ~ dexp(1 / sigma)
      }
    }

    # 2. Survival Part - Weibull & Current Value
    for (i in 1:N_subj) {
      b[i, 1:2] ~ dmnorm(mu.b[1:2], D_inv[1:2, 1:2])
      
      mu_T[i] <- beta[1] + beta[2]*age[i]  + beta[3]*years[i]  + 
           b[i, 1] + b[i, 2]*years[i]
      
      hazard[i] <- lambda * rho * pow(max(years[i], 1e-7), rho - 1) * exp(gamma_surv[1]*age[i] + alpha * mu_T[i])
      
      for (k in 1:7) {
        u[i, k] <- (years[i] / 2) * GK.nodes[k] + (years[i] / 2)
        mu_u[i, k] <- beta[1] + beta[2]*age[i] + beta[3]*u[i, k] + b[i, 1] + b[i, 2]*u[i, k]
        h_u[i, k] <- lambda * rho * pow(max(u[i, k], 1e-7), rho - 1) * exp(gamma_surv[1]*age[i] + alpha * mu_u[i, k])
      }
      cum_hazard[i] <- (years[i] / 2) * inprod(GK.weights[1:7], h_u[i, 1:7])
      
      logL[i] <- delta[i] * log(max(1e-10, hazard[i])) - cum_hazard[i]
      phi[i] <- -logL[i] + 100000
      zeros[i] ~ dpois(phi[i])
    }

    # 3. Priors
    for (p in 1:3) { beta[p] ~ dnorm(0, 0.01) }
    for (q in 1:1) { gamma_surv[q] ~ dnorm(0, 0.01) }
    alpha ~ dnorm(0, 0.01)
    
    tau.sigma ~ dgamma(0.01, 0.01)
    sigma <- 1 / tau.sigma 
    
    log_lambda ~ dnorm(0, 0.01) 
    lambda <- exp(log_lambda)
    rho ~ dunif(0.1, 5) 
    
    mu.b[1] <- 0; mu.b[2] <- 0
    D_inv[1:2, 1:2] ~ dwish(R.mat[1:2, 1:2], k.wishart)
    D[1:2, 1:2] <- inverse(D_inv[,])
  }
", file = "jm_ald_weibull_pbc2_current.jags")

# ========================================================
# 2. 定义 C++ 极速积分函数 (彻底将生存输入降维为基础 double，封死越界)
# ========================================================
cpp_code <- '
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double calc_cum_hazard_weibull_cpp(double t_val, double lam, double rho, double alpha_val, NumericVector beta_val, double gamma_val, double age_val, NumericVector b_val, NumericVector GK_nodes, NumericVector GK_weights) {
  if (t_val <= 0) return 0.0;
  double sum_res = 0.0;
  double half_t = t_val / 2.0;
  int n_nodes = GK_nodes.size();
  for(int k = 0; k < n_nodes; ++k) {
      double u = half_t * GK_nodes[k] + half_t;
      double mu_u = beta_val[0] + beta_val[1]*age_val + beta_val[2]*u + b_val[0] + b_val[1]*u;
      double h_u = lam * rho * pow(u, rho - 1.0) * exp(gamma_val*age_val + alpha_val * mu_u);
      sum_res += GK_weights[k] * h_u;
  }
  return half_t * sum_res;
}
'
sourceCpp(code = cpp_code)  

# ========================================================
# 3. 真实数据准备 (PBC2)
# ========================================================
data(pbc2)
data(pbc2.id)

df_surv_real <- pbc2.id %>%
  mutate(event = status2) %>%
  dplyr::select(id, years, event, age)

df_long_real <- pbc2 %>%
  mutate(time = year, Y = log(albumin)) %>%
  dplyr::select(id, time, Y) %>%
  filter(!is.na(Y))

all_ids <- unique(df_surv_real$id)

# ========================================================
# 4. 全局参数设置与并行环境初始化
# ========================================================
set.seed(2026)
k_folds <- 5
folds_index <- createFolds(factor(df_surv_real$event), k = k_folds, list = FALSE)
folds <- as.numeric(folds_index)

GK.nodes <- c(-0.9491079, -0.7415312, -0.4058452, 0, 0.4058452, 0.7415312, 0.9491079)
GK.weights <- c(0.1294850, 0.2797054, 0.3818301, 0.4179592, 0.3818301, 0.2797054, 0.1294850)

time_windows <- data.frame(landmark_t = c(2.0, 4.0, 6.0), horizon_s = c(4.0, 6.0, 8.0))

target_P <- 100; target_Q <- 30; n_burn <- 50
prop_Sigma <- diag(c(0.01, 0.0005))

slurm_cores <- as.numeric(Sys.getenv("SLURM_NTASKS"))
if (is.na(slurm_cores)) { slurm_cores <- min(5, detectCores() - 1) }

cl <- makeCluster(slurm_cores, outfile = "")
registerDoParallel(cl)
clusterExport(cl, "cpp_code")
clusterEvalQ(cl, {
  library(Rcpp)
  sourceCpp(code = cpp_code, cacheDir = tempdir()) 
})

# ========================================================
# 5. 模型执行主循环
# ========================================================
tau_values <- c(0.25, 0.50, 0.75)

for (current_tau in tau_values) {
  cat(sprintf("\n\n========================================================\n"))
  cat(sprintf(">>> 开始执行分位数 tau = %.2f 的 PBC2 交叉验证...\n", current_tau))
  cat(sprintf("========================================================\n"))
  
  start_time <- Sys.time()
  k1 <- (1 - 2*current_tau) / (current_tau * (1 - current_tau))
  k2_sq <- 2 / (current_tau * (1 - current_tau))
  
  cv_results <- foreach(fold = 1:k_folds, .options.RNG = 2026, 
                        .packages = c("MASS", "survival", "rjags", "coda", "GIGrvg", "Rcpp", "dplyr"),
                        .export = c("GK.nodes", "GK.weights", "k1", "k2_sq", "prop_Sigma", 
                                    "time_windows", "current_tau", "df_surv_real", "df_long_real",
                                    "all_ids", "folds", "target_P", "target_Q", "n_burn"), 
                        .noexport = "calc_cum_hazard_weibull_cpp") %dorng% {
                          
                          test_ids <- all_ids[folds == fold]
                          train_ids <- all_ids[folds != fold]

                          df_surv_train <- df_surv_real %>% filter(id %in% train_ids)
                          df_surv_test  <- df_surv_real %>% filter(id %in% test_ids)
                          df_long_train <- df_long_real %>% filter(id %in% train_ids)

                          train_age_mean <- mean(df_surv_train$age, na.rm = TRUE)
                          train_age_sd   <- sd(df_surv_train$age, na.rm = TRUE)

                          df_surv_train$age_z <- (df_surv_train$age - train_age_mean) / train_age_sd
                          df_surv_test$age_z  <- (df_surv_test$age - train_age_mean) / train_age_sd
                          df_long_train$age_z <- df_surv_train$age_z[match(df_long_train$id, df_surv_train$id)]
   
                          df_surv_train$id_jags <- 1:nrow(df_surv_train)
                          df_long_train$id_jags <- match(df_long_train$id, df_surv_train$id)
                          n_train <- nrow(df_surv_train)
                          
                          num_meas_train <- as.numeric(table(factor(df_long_train$id_jags, levels = 1:n_train)))
                          Y_mat <- matrix(NA, n_train, max(num_meas_train))
                          time_mat <- matrix(0, n_train, max(num_meas_train)) 
                          
                          for(i in 1:n_train) {
                            idx <- which(df_long_train$id_jags == i)
                            if(length(idx) > 0){
                              Y_mat[i, 1:length(idx)] <- df_long_train$Y[idx]
                              time_mat[i, 1:length(idx)] <- df_long_train$time[idx] 
                            }
                          }
                          R_mat_adjusted <- matrix(c(1, 0, 0, 0.1), 2, 2)
                          jags_data_train <- list(
                            N_subj = n_train, num_meas = num_meas_train, Y = Y_mat, time = time_mat,             
                            years = df_surv_train$years, delta = df_surv_train$event, 
                            age = df_surv_train$age_z, tau_quant = current_tau, 
                            R.mat = R_mat_adjusted, k.wishart = 3, zeros = rep(0, n_train),
                            GK.nodes = GK.nodes, GK.weights = GK.weights
                          )
                          
                          fit_lme <- try(nlme::lme(Y ~ age_z + time, random = ~ time | id_jags, data = df_long_train, control = nlme::lmeControl(opt = "optim")), silent = TRUE)
                          init_beta <- if(!inherits(fit_lme, "try-error")) as.numeric(nlme::fixef(fit_lme)) else rnorm(3, 0, 0.1)
                          
                          fit_surv <- try(survival::survreg(Surv(years, event) ~ age_z, data = df_surv_train, dist = "weibull"), silent = TRUE)
                          if(!inherits(fit_surv, "try-error")) {
                            init_gamma <- -as.numeric(coef(fit_surv)[2]) / fit_surv$scale
                            init_rho <- 1 / fit_surv$scale
                            init_log_lam <- -as.numeric(coef(fit_surv)[1]) / fit_surv$scale
                          } else {
                            init_gamma <- rnorm(1, 0, 0.1); init_rho <- 1.0; init_log_lam <- log(0.01)
                          }

                          inits_func <- function(chain_id) {
                            list(
                              beta = as.numeric(init_beta) + rnorm(3, 0, 0.05),
                              gamma_surv = as.numeric(init_gamma) + rnorm(1, 0, 0.05),
                              alpha = runif(1, 0.1, 0.5), 
                              log_lambda = init_log_lam + rnorm(1, 0, 0.05), 
                              rho = init_rho * exp(rnorm(1, 0, 0.05))
                            )
                          }
                          inits_list <- list(inits_func(1), inits_func(2))
                          
                          m <- jags.model("jm_ald_weibull_pbc2_current.jags", data = jags_data_train, inits = inits_list, n.chains = 2, n.adapt = 15000, quiet = TRUE)
                          update(m, 80000, progress.bar = "none") 
                          
                          var_names_to_monitor <- c("beta", "gamma_surv", "alpha", "sigma", "lambda", "rho", "D_inv") 
                          samples <- coda.samples(m, variable.names = var_names_to_monitor, n.iter = 150000, thin = 260)
                          
                          summ <- summary(samples)
                          rhat <- tryCatch(gelman.diag(samples, multivariate = FALSE)$psrf[, 1], error = function(e) rep(NA, nrow(summ$statistics)))
                          
                          post_mat_full <- as.matrix(samples) 
                          actual_P <- min(nrow(post_mat_full), target_P) 
                          post_mat = post_mat_full[sample(1:nrow(post_mat_full), actual_P), ]
                          
                          idx_beta  <- grep("^beta\\[", colnames(post_mat))
                          idx_gamma <- grep("^gamma_surv\\[|^gamma_surv$", colnames(post_mat))
                          
                          all_windows_pred_list <- list() 
                          
                          for (w in 1:nrow(time_windows)) {
                            current_t <- time_windows$landmark_t[w]
                            current_s <- time_windows$horizon_s[w]
                            
                            # 正确代码：直接从已经含有 age_z 的 df_surv_test 中过滤，且不需要再判断 id %in% test_ids
                            df_surv_test_sub <- df_surv_test %>% filter(years > current_t)
                            if (nrow(df_surv_test_sub) == 0) next 
                            
                            pred_results <- data.frame(
                              fold = fold, window_t = current_t, window_s = current_s, 
                              id = df_surv_test_sub$id, true_years = df_surv_test_sub$years, event = df_surv_test_sub$event, pi_pred = NA
                            )
                            
                            for (idx in 1:nrow(df_surv_test_sub)) {
                              new_id <- df_surv_test_sub$id[idx]
                              history_Y <- df_long_real %>% filter(id == new_id & time <= current_t)
                              Y_obs <- history_Y$Y; t_obs <- history_Y$time
                              age_i <- df_surv_test_sub$age_z[idx]
                              n_i <- length(Y_obs)
                              
                              surv_prob_Q <- numeric(actual_P * target_Q); counter <- 1
                              b_curr <- c(0, 0); e_curr <- rep(1, n_i)
                              
                              for (p in 1:actual_P) {
                                beta_p <- as.numeric(post_mat[p, idx_beta])
                                # 💡重点：直接提取为双精度纯数字数值，彻底斩断 extent=0 报错
                                gamma_surv_val <- as.numeric(post_mat[p, idx_gamma])[1]
                                alpha_val      <- as.numeric(post_mat[p, "alpha"])[1]
                                sig_p          <- as.numeric(post_mat[p, "sigma"])[1]
                                lambda_p       <- as.numeric(post_mat[p, "lambda"])[1]
                                rho_p          <- as.numeric(post_mat[p, "rho"])[1]
                                
                                Tau_b_p <- matrix(c(post_mat[p, "D_inv[1,1]"], post_mat[p, "D_inv[2,1]"], 
                                                    post_mat[p, "D_inv[1,2]"], post_mat[p, "D_inv[2,2]"]), 2, 2)
                                
                                for (q_iter in 1:(target_Q + n_burn)) {
                                  if (n_i > 0) {
                                    mu_ij <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*t_obs + b_curr[1] + b_curr[2]*t_obs
                                    gig_chi <- pmax((Y_obs - mu_ij)^2 / (k2_sq * sig_p), 1e-6)
                                    e_curr <- rgig(n = n_i, lambda = 0.5, chi = gig_chi, psi = (k1^2 + 2*k2_sq) / (k2_sq * sig_p))
                                  }
                                  
                                  calc_log_post_b <- function(b_val) {
                                    log_prior <- -0.5 * as.numeric(t(b_val) %*% Tau_b_p %*% b_val)
                                    log_lik_long <- 0
                                    if (n_i > 0) {
                                      mu_val <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*t_obs + b_val[1] + b_val[2]*t_obs
                                      log_lik_long <- sum( - (Y_obs - mu_val - k1 * e_curr)^2 / (2 * k2_sq * sig_p * e_curr) )
                                    }
                                    cum_H <- calc_cum_hazard_weibull_cpp(current_t, lambda_p, rho_p, alpha_val, beta_p, gamma_surv_val, age_i, b_val, GK.nodes, GK.weights)
                                    return(log_prior + log_lik_long - cum_H)
                                  }
                                  
                                  log_post_curr <- calc_log_post_b(b_curr)
                                  b_cand <- b_curr + MASS::mvrnorm(1, mu = c(0,0), Sigma = prop_Sigma)
                                  log_post_cand <- calc_log_post_b(b_cand)

                                  # 拦截 NaN/NA 导致的报错，且只有在数值有效时才进行 MH 比较
                                  if (!is.na(log_post_cand) && !is.na(log_post_curr)) {
                                    if (log_post_cand - log_post_curr > log(runif(1))) {
                                      b_curr <- b_cand
                                    }
                                  }  
                                  
                                  if (q_iter > n_burn) {
                                    H_land  <- calc_cum_hazard_weibull_cpp(current_t, lambda_p, rho_p, alpha_val, beta_p, gamma_surv_val, age_i, b_curr, GK.nodes, GK.weights)
                                    H_horiz <- calc_cum_hazard_weibull_cpp(current_s, lambda_p, rho_p, alpha_val, beta_p, gamma_surv_val, age_i, b_curr, GK.nodes, GK.weights)
                                    surv_prob_Q[counter] <- exp(-(H_horiz - H_land))
                                    counter <- counter + 1
                                  }
                                } 
                              } 
                              pred_results$pi_pred[idx] <- mean(surv_prob_Q, na.rm = TRUE)
                            }
                            all_windows_pred_list[[w]] <- pred_results
                          }
                          
                          list(
                            predictions = do.call(rbind, all_windows_pred_list), 
                            samples = samples, 
                            post_mat = post_mat_full,
                            train_data = df_surv_train,
                            long_data = df_long_train,
                            estimates = data.frame(param = rownames(summ$statistics), mean = summ$statistics[,"Mean"], sd = summ$statistics[,"SD"]),
                            rhat = data.frame(param = names(rhat), rhat = rhat)
                          )
                        }
  
  run_time <- Sys.time() - start_time
  all_predictions <- do.call(rbind, lapply(cv_results, `[[`, "predictions"))
  all_rhat <- do.call(rbind, lapply(cv_results, `[[`, "rhat"))
  all_samples_list <- lapply(cv_results, `[[`, "samples")     
  all_post_mats <- lapply(cv_results, `[[`, "post_mat")       
  
  valid_eval <- all_predictions %>%
    filter(!is.na(pi_pred)) %>%
    filter(!(true_years <= window_s & event == 0)) %>%
    mutate(survived_s = ifelse(true_years > window_s, 1, 0))
  
  metrics_summary <- valid_eval %>%
    group_by(window_t, window_s) %>%
    summarise(
      N_Test = n(),
      Brier_Score = mean((pi_pred - survived_s)^2),
      AUC = tryCatch(as.numeric(pROC::roc(survived_s, pi_pred, direction="auto", quiet=TRUE)$auc), error = function(e) NA),
      .groups = "drop"
    )
  
  cat("\n=== PBC2 预测评估结果 (Tau =", current_tau, ") ===\n")
  print(as.data.frame(metrics_summary), digits = 4)
  
  rdata_filename <- sprintf("pbc2_current_value_albumin_tau_%.2f.RData", current_tau)
  save(cv_results, all_predictions, metrics_summary, all_rhat, all_samples_list, all_post_mats, run_time, file = rdata_filename)
  cat(sprintf("✅ 结果已存至 %s\n", rdata_filename))
}

stopCluster(cl)
cat("\n🎉 PBC2 真实数据的所有分位数 (0.25, 0.50, 0.75) 运行完毕！\n")