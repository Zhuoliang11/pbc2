library(MASS)
library(survival)
library(rjags)
load.module("glm")
library(doParallel)
library(foreach)
library(doRNG)
library(GIGrvg)
library(Rcpp)
library(dplyr)
library(JM)     
library(pROC)   
library(nlme)
library(caret)

# ========================================================
# 1. C++ 极速累积风险函数 (共享随机效应版)
# ========================================================
cpp_code_shared <- '
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double calc_cum_hazard_shared_cpp(double t_val, double lam, double rho, NumericVector alpha_val, NumericVector gamma_val, double age_val, NumericVector b_val) {
  if (t_val <= 0) return 0.0;
  double eta_surv = gamma_val[0]*age_val + alpha_val[0]*b_val[0] + alpha_val[1]*b_val[1];
  return lam * pow(t_val, rho) * exp(eta_surv);
}
'
sourceCpp(code = cpp_code_shared)

# ========================================================
# 2. 真实数据准备 (PBC2)
# ========================================================
data(pbc2)
data(pbc2.id)

df_surv_real <- pbc2.id %>%
  mutate(
    event = status2,
  ) %>%
  
  # 保留原始的 age，坚决不要在这里做 scale！
  dplyr::select(id, years, event, age)

df_long_real <- pbc2 %>%
  mutate(time = year, Y = log(serBilir)) %>%
  dplyr::select(id, time, Y) %>%
  filter(!is.na(Y))

all_ids <- unique(df_surv_real$id)

# ========================================================
# 3. 全局参数与集群并行配置
# ========================================================
set.seed(2026)
k_folds <- 5
folds_index <- createFolds(factor(df_surv_real$event), k = k_folds, list = FALSE)
folds <- as.numeric(folds_index)

time_windows <- data.frame(
  landmark_t = c(2.0, 4.0, 6.0),
  horizon_s  = c(4.0, 6.0, 8.0) 
)

target_P <- 200; target_Q <- 100; n_burn <- 50
# 大幅缩减随机游走的步长，确保 MH 抽样器在预测阶段能被有效接受
prop_Sigma <- diag(c(0.01, 0.0005))

slurm_cores <- as.numeric(Sys.getenv("SLURM_NTASKS"))
if (is.na(slurm_cores)) slurm_cores <- min(5, detectCores() - 1)

cl <- makeCluster(slurm_cores, outfile = "")
registerDoParallel(cl)

clusterExport(cl, "cpp_code_shared")
clusterEvalQ(cl, {
  library(Rcpp)
  sourceCpp(code = cpp_code_shared, cacheDir = tempdir()) 
})

# ========================================================
# 4. 主循环：遍历多个 Tau 分位数 (已完全清理括号嵌套与作用域 bug)
# ========================================================
tau_values <- c(0.25, 0.50, 0.75)

for (current_tau in tau_values) {
   
   cat(sprintf("\n========================================================\n"))
   cat(sprintf(">>> 开始执行 PBC2 交叉验证: Tau = %.2f\n", current_tau))
   cat(sprintf("========================================================\n"))
   start_time <- Sys.time()
   
   k1 <- (1 - 2*current_tau) / (current_tau * (1 - current_tau))
   k2_sq <- 2 / (current_tau * (1 - current_tau))
   
   # --- 并行交叉验证循环 ---
   cv_results <- foreach(fold = 1:k_folds, .options.RNG = 2026, 
                         .packages = c("MASS", "survival", "rjags", "coda", "GIGrvg", "Rcpp", "dplyr"),
                         .export = c("k1", "k2_sq", "prop_Sigma", "time_windows", "df_surv_real", 
                                     "df_long_real", "folds", "all_ids", "current_tau", 
                                     "target_P", "target_Q", "n_burn"),
                         .noexport = "calc_cum_hazard_shared_cpp") %dorng% {
                            
                            test_ids <- all_ids[folds == fold]
                            train_ids <- all_ids[folds != fold]
 
                            df_surv_train <- df_surv_real %>% filter(id %in% train_ids)
                            df_surv_test  <- df_surv_real %>% filter(id %in% test_ids)
                            df_long_train <- df_long_real %>% filter(id %in% train_ids)
 
                            # 1. 计算均值和标准差
                            train_age_mean <- mean(df_surv_train$age, na.rm = TRUE)
                            train_age_sd   <- sd(df_surv_train$age, na.rm = TRUE)
 
                            # 2. 标准化
                            df_surv_train$age_z <- (df_surv_train$age - train_age_mean) / train_age_sd
                            df_surv_test$age_z  <- (df_surv_test$age - train_age_mean) / train_age_sd
 
                            # 3. 映射
                            df_long_train$age_z <- df_surv_train$age_z[match(df_long_train$id, df_surv_train$id)]
                            
                            # 4. 内部 ID 编排
                            df_surv_train$id_jags <- 1:nrow(df_surv_train)
                            df_long_train$id_jags <- match(df_long_train$id, df_surv_train$id)
                            n_train <- nrow(df_surv_train)
                            
                            num_meas_train <- as.numeric(table(factor(df_long_train$id_jags, levels = 1:n_train)))
                            Y_mat <- matrix(NA, n_train, max(num_meas_train))
                            time_mat <- matrix(0, n_train, max(num_meas_train)) 
                            
                            for(i in 1:n_train) {
                              idx <- which(df_long_train$id_jags == i)
                              if(length(idx) > 0) {
                                Y_mat[i, 1:length(idx)] <- df_long_train$Y[idx]
                                time_mat[i, 1:length(idx)] <- df_long_train$time[idx] 
                              }
                            }
                            R_mat_adjusted <- matrix(c(1, 0, 0, 0.1), 2, 2)
                            jags_data_train <- list(
                              N_subj = n_train, num_meas = num_meas_train, Y = Y_mat, time = time_mat,             
                              years = df_surv_train$years, delta = df_surv_train$event, 
                              age = df_surv_train$age_z, tau_quant = current_tau, 
                              R.mat = R_mat_adjusted, k.wishart = 3, zeros = rep(0, n_train)
                            )
                            
                            # ==========================================
                            # 粗糙模型预估计
                            # ==========================================
                            fit_lme <- try(nlme::lme(Y ~ age_z + time, random = ~ time | id_jags, data = df_long_train, control = nlme::lmeControl(opt = "optim")), silent = TRUE)
                            init_beta <- if(!inherits(fit_lme, "try-error")) as.numeric(nlme::fixef(fit_lme)) else rnorm(3, 0, 0.1)
                            fit_surv <- try(survival::survreg(Surv(years, event) ~ age_z, data = df_surv_train, dist = "weibull"), silent = TRUE)
                            if(!inherits(fit_surv, "try-error")) {
                              init_gamma <- -as.numeric(coef(fit_surv)[2]) / fit_surv$scale
                              init_rho <- 1 / fit_surv$scale
                              init_log_lam <- -as.numeric(coef(fit_surv)[1]) / fit_surv$scale
                            } else {
                              init_gamma <- rnorm(1, 0, 0.1); init_rho <- 1.0; init_log_lam <- log(0.01)
                            }
                            
                            inits_func <- function(chain_id) {
                              list(
                                beta = as.numeric(init_beta) + rnorm(3, 0, 0.05),
                                gamma = as.numeric(init_gamma) + rnorm(1, 0, 0.05),
                                alpha = c(runif(1, 0.1, 0.5), rnorm(1, 0, 0.1)),
                                log_lambda = init_log_lam + rnorm(1, 0, 0.05), 
                                gamma_shape = init_rho * exp(rnorm(1, 0, 0.05))
                              )
                            }
                            inits_list <- list(inits_func(1), inits_func(2))
                            
                            m <- jags.model("jm_shared_re_pbc2.jags", data = jags_data_train, inits = inits_list, n.chains = 2, n.adapt = 15000, quiet = TRUE)
                            update(m, 80000, progress.bar = "none") 
                            
                            var_names_to_monitor <- c("beta", "gamma", "alpha", "sigma", "lambda", "gamma_shape", "D_inv")
                            samples <- coda.samples(m, variable.names = var_names_to_monitor, n.iter = 150000, thin = 260)
                            
                            summ <- summary(samples)
                            rhat <- tryCatch(gelman.diag(samples, multivariate = FALSE)$psrf[, 1], error = function(e) rep(NA, nrow(summ$statistics)))
                            
                            post_mat_full <- as.matrix(samples) 
                            actual_P <- min(nrow(post_mat_full), target_P) 
                            post_mat <- post_mat_full[sample(1:nrow(post_mat_full), actual_P), ]
                            
                            all_windows_pred_list <- list() 
                            
                            # 获取列索引并加入防御性检查
                            idx_beta  <- grep("^beta\\[", colnames(post_mat))
                            idx_gamma <- grep("^gamma\\[|^gamma$", colnames(post_mat))
                            idx_alpha <- grep("^alpha\\[", colnames(post_mat))
                            
                            for (w in 1:nrow(time_windows)) {
                              current_t <- time_windows$landmark_t[w]
                              current_s <- time_windows$horizon_s[w]
                              
                              df_surv_test_sub <- df_surv_test %>% filter(years > current_t)
                              if (nrow(df_surv_test_sub) == 0) next 
                              
                              pred_results <- data.frame(
                                fold = fold, window_t = current_t, window_s = current_s,  
                                id = df_surv_test_sub$id, true_years = df_surv_test_sub$years, event = df_surv_test_sub$event, pi_pred = NA
                              )
                              
                              for (idx in 1:nrow(df_surv_test_sub)) {
                                new_id <- df_surv_test_sub$id[idx]
                                history_Y <- df_long_real %>% filter(id == new_id & time <= current_t)
                                
                                Y_obs <- history_Y$Y; t_obs <- history_Y$time
                                age_i <- df_surv_test_sub$age_z[idx]
                                n_i <- length(Y_obs)
                                
                                surv_prob_Q <- numeric(actual_P * target_Q); counter <- 1
                                b_curr <- c(0, 0); e_curr <- rep(1, n_i)
                                
                                for (p in 1:actual_P) {
                                  beta_p  <- as.numeric(post_mat[p, idx_beta])
                                  gamma_p <- as.numeric(post_mat[p, idx_gamma])
                                  alpha_p <- as.numeric(post_mat[p, idx_alpha])
                                  
                                  # 防御性断言：确保提取出的后验不是空向量
                                  if(length(beta_p) == 0) beta_p <- c(0,0,0)
                                  if(length(gamma_p) == 0) gamma_p <- 0
                                  if(length(alpha_p) == 0) alpha_p <- c(0,0)
                                  
                                  lam_p <- post_mat[p, "lambda"]; rho_p <- post_mat[p, "gamma_shape"]; sig_p <- post_mat[p, "sigma"]
                                  
                                  Tau_b_p <- matrix(c(post_mat[p, "D_inv[1,1]"], post_mat[p, "D_inv[2,1]"], 
                                                      post_mat[p, "D_inv[1,2]"], post_mat[p, "D_inv[2,2]"]), 2, 2)
                                  
                                  for (q_iter in 1:(target_Q + n_burn)) {
                                    if (n_i > 0) {
                                      mu_ij <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*t_obs + b_curr[1] + b_curr[2]*t_obs
                                      gig_chi <- pmax((Y_obs - mu_ij)^2 / (k2_sq * sig_p), 1e-6)
                                      e_curr <- rgig(n = n_i, lambda = 0.5, chi = gig_chi, psi = (k1^2 + 2*k2_sq) / (k2_sq * sig_p))
                                    }
                                    
                                    # 修复处的内部函数定义
                                    calc_log_post_b <- function(b_val) {
                                      log_prior <- -0.5 * as.numeric(t(b_val) %*% Tau_b_p %*% b_val)
                                      log_lik_long <- 0
                                      if (n_i > 0) {
                                        mu_val <- beta_p[1] + beta_p[2]*age_i +  beta_p[3]*t_obs + b_val[1] + b_val[2]*t_obs
                                        log_lik_long <- sum( - (Y_obs - mu_val - k1 * e_curr)^2 / (2 * k2_sq * sig_p * e_curr) )
                                      }
                                      # 保障：此处最后一个参数必须为传入函数的 b_val，而非外部的 b_curr 
                                      cum_H <- calc_cum_hazard_shared_cpp(current_t, lam_p, rho_p, alpha_p, gamma_p, age_i, b_val)
                                      return(log_prior + log_lik_long - cum_H)
                                    }
                                    
                                    log_post_curr <- calc_log_post_b(b_curr)
                                    b_cand <- b_curr + MASS::mvrnorm(1, mu = c(0,0), Sigma = prop_Sigma)
                                    if (calc_log_post_b(b_cand) - log_post_curr > log(runif(1))) b_curr <- b_cand
                                    
                                    if (q_iter > n_burn) {
                                      H_land  <- calc_cum_hazard_shared_cpp(current_t, lam_p, rho_p, alpha_p, gamma_p, age_i, b_curr)
                                      H_horiz <- calc_cum_hazard_shared_cpp(current_s, lam_p, rho_p, alpha_p, gamma_p, age_i, b_curr)
                                      surv_prob_Q[counter] <- exp(-(H_horiz - H_land))
                                      counter <- counter + 1
                                    }
                                  } 
                                } 
                                pred_results$pi_pred[idx] <- mean(surv_prob_Q, na.rm = TRUE)
                              }
                              all_windows_pred_list[[w]] <- pred_results
                            }
                            
                            return(list(predictions = do.call(rbind, all_windows_pred_list), samples = samples, 
                                        post_mat = post_mat_full,
                                        train_data = df_surv_train,
                                        long_data = df_long_train,
                                        rhat = data.frame(param = names(rhat), rhat = rhat)))
                         }
   
   run_time <- Sys.time() - start_time
   all_predictions <- do.call(rbind, lapply(cv_results, `[[`, "predictions"))
   all_rhat <- do.call(rbind, lapply(cv_results, `[[`, "rhat"))
   all_samples_list <- lapply(cv_results, `[[`, "samples")     
   all_post_mats <- lapply(cv_results, `[[`, "post_mat")
   
   # ========================================================
   # 5. 模型评估与保存
   # ========================================================
   rhat_list <- do.call(rbind, lapply(cv_results, `[[`, "rhat"))
   cat(sprintf("\n=== Rhat 诊断汇总 (Tau = %.2f) ===\n", current_tau))
   print(rhat_list %>% group_by(param) %>% summarise(mean_rhat = mean(rhat), max_rhat = max(rhat)))
   
   valid_eval <- all_predictions %>%
     filter(!is.na(pi_pred)) %>%
     filter(!(true_years <= window_s & event == 0)) %>%
     mutate(survived_s = ifelse(true_years > window_s, 1, 0))
   
   metrics_summary <- valid_eval %>%
     group_by(window_t, window_s) %>%
     summarise(
       Tau = current_tau,
       N_Test = n(),
       Brier_Score = mean((pi_pred - survived_s)^2),
       AUC = as.numeric(pROC::roc(survived_s, pi_pred, direction="auto", quiet=TRUE)$auc),
       .groups = "drop"
     )
   
   cat(sprintf("\n=== PBC2 预测评估结果 (Tau = %.2f) ===\n", current_tau))
   print(as.data.frame(metrics_summary), digits = 4)
   
   rdata_filename <- sprintf("pbc2_shared_re_bili_tau_%.2f.RData", current_tau)
   save(cv_results, all_predictions, metrics_summary, all_rhat, rhat_list, all_samples_list, all_post_mats, run_time, file = rdata_filename)
   cat(sprintf("✅ 当前分位数执行完毕，结果已保存至: %s\n", rdata_filename))
}

stopCluster(cl)
cat("\n🎉 全部 5-Fold 交叉验证 (Tau = 0.25, 0.50, 0.75) 运行完毕！\n")
