# Code availability

Use this short text in the Appendix after replacing the placeholder:

> **Code availability**  
> Code for the non-spatial simulation studies and PBC2 application is available at <REPOSITORY-URL>. The HIV spatial model code is not publicly available.

If the dissertation should not explicitly mention the excluded spatial code, use:

> **Code availability**  
> Code accompanying this dissertation is available at <REPOSITORY-URL>.

A tag, release version, or commit hash is optional for this wording.
