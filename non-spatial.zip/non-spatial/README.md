# Dissertation code

R and JAGS code for the non-spatial PBC2 simulation studies and data application.

The HIV spatial model, Stan programs, and the R scripts that embed those programs are intentionally not included in this public repository.

## Repository layout

```text
README.md
jags/                  JAGS model files
simulation/pbc2/       PBC2 simulation scripts
application/pbc2/      PBC2 no-fold and five-fold analyses
figures/               Figure-code documentation
data_processing/       Data-processing documentation
data/                   Data-availability documentation
```

## Software requirements

The scripts require R, JAGS, and the R packages used at the beginning of each script, including `rjags`, `JM`, `MASS`, `survival`, `GIGrvg`, `Rcpp`, `nlme`, `caret`, `pROC`, `foreach`, `doParallel`, and `doRNG`.

## Data availability

No original patient-level data, generated simulation datasets, fitted posterior objects, or result files are included.

The application scripts load the `pbc2` and `pbc2.id` data objects through the installed `JM` R package. Simulation datasets are generated in memory when the simulation scripts are run; only the code that generates them is included.

## Main scripts

- `simulation/pbc2/my_sim_shared.R`: Shared random-effects simulation.
- `simulation/pbc2/run_sim_all_current.R`: Current-value simulation.
- `simulation/pbc2/jifen_tau_025.R`, `jifen_tau_050.R`, and `jifen_tau_075.R`: Integral/cumulative-value simulations.
- `application/pbc2/nofold/`: Full-data application scripts.
- `application/pbc2/5_fold/`: Five-fold application and alternate-window scripts.

Files ending `_al.R` or `_foldal.r` contain alternate-window analyses and are not duplicate copies.
