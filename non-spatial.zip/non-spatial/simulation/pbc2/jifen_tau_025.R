library(MASS)
library(survival)
library(rjags)
load.module("glm")
library(doParallel)
library(foreach)
library(doRNG)
library(GIGrvg)
library(Rcpp)  
library(nlme)
library(caret)
library(dplyr)
library(pROC)

# ========================================================
# 0. 输出 JAGS 模型文件 (中心化时间 + 模拟集的 4 个 Beta)
# ========================================================
cat("
  model {
    prec_k2 <- (tau_quant * (1 - tau_quant)) / 2
    k1 <- (1 - 2 * tau_quant) / (tau_quant * (1 - tau_quant))
    
    # 1. 纵向子模型 (使用 time_c)
    for (i in 1:N_subj) {
      for (j in 1:num_meas[i]) {
        mu_long[i, j] <- beta[1] + beta[2]*age[i] + beta[3]*drug[i] + beta[4]*time_c[i, j] + 
                 b[i, 1] + b[i, 2]*time_c[i, j]
        Y[i, j] ~ dnorm(mu_long[i, j] + k1 * e[i, j], prec_long[i, j])
        prec_long[i, j] <- prec_k2 / max(sigma * e[i, j], 1e-7)
        e[i, j] ~ dexp(1 / sigma)
      }
    }

    # 2. 生存子模型 
    for (i in 1:N_subj) {
      b[i, 1:2] ~ dmnorm(mu.b[1:2], D_inv[1:2, 1:2])
      
      # 纯粹的中心化截距
      mu_c[i] <- beta[1] + beta[2]*age[i] + beta[3]*drug[i] + b[i, 1]
      mu_1[i] <- beta[4] + b[i, 2]
      
      # 终端风险计算
      m_T[i] <- mu_c[i] + mu_1[i] * (years[i] - mean_time)
      m_prime_T[i] <- mu_1[i]
      m_int_T[i] <- mu_c[i] * years[i] + mu_1[i] * (0.5 * pow(years[i], 2) - mean_time * years[i])
      
      assoc_T[i] <- alpha[1]*m_T[i] + alpha[2]*m_prime_T[i] + alpha[3]*m_int_T[i]
      hazard[i] <- lambda * rho * pow(max(years[i], 1e-7), rho - 1) * exp(gamma_surv[1]*age[i] + gamma_surv[2]*drug[i] + assoc_T[i])
      
      # 高斯-克朗罗德积分
      for (k in 1:7) {
        u[i, k] <- (years[i] / 2) * GK.nodes[k] + (years[i] / 2)
        
        m_u[i, k] <- mu_c[i] + mu_1[i] * (u[i, k] - mean_time)
        m_prime_u[i, k] <- mu_1[i]
        m_int_u[i, k] <- mu_c[i] * u[i, k] + mu_1[i] * (0.5 * pow(u[i, k], 2) - mean_time * u[i, k])
        
        assoc_u[i, k] <- alpha[1]*m_u[i, k] + alpha[2]*m_prime_u[i, k] + alpha[3]*m_int_u[i, k]
        h_u[i, k] <- lambda * rho * pow(max(u[i, k], 1e-7), rho - 1) * exp(gamma_surv[1]*age[i] + gamma_surv[2]*drug[i] + assoc_u[i, k])
      }
      
      cum_hazard[i] <- (years[i] / 2) * inprod(GK.weights[1:7], h_u[i, 1:7])
      
      logL[i] <- delta[i] * log(max(1e-10, hazard[i])) - cum_hazard[i]
      phi[i] <- -logL[i] + 100000
      zeros[i] ~ dpois(phi[i])
    }

    # 3. 先验分布
    for (p in 1:4) { beta[p] ~ dnorm(0, 0.1) } 
    for (q in 1:2) { gamma_surv[q] ~ dnorm(0, 0.01) }
    for (a in 1:3) { alpha[a] ~ dnorm(0, 0.01) }

    tau.sigma ~ dgamma(0.01, 0.01)
    sigma <- 1 / tau.sigma 
    
    log_lambda ~ dnorm(0, 0.1)  
    lambda <- exp(log_lambda)
    rho ~ dunif(0.1, 5) 
    
    mu.b[1] <- 0; mu.b[2] <- 0
    D_inv[1:2, 1:2] ~ dwish(R.mat[1:2, 1:2], k.wishart)
    D[1:2, 1:2] <- inverse(D_inv[,])
  }
", file = "jm_sim_centered.jags")

# ========================================================
# 1. 定义 C++ 极速积分函数 (支持 mean_time 偏移)
# ========================================================
cpp_code <- '
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double calc_cum_hazard_weibull_cpp(double t_val, double lam, double rho, 
                                   NumericVector alpha_val, NumericVector beta_val, 
                                   NumericVector gamma_val, NumericVector W_val, 
                                   NumericVector b_val, NumericVector GK_nodes, 
                                   NumericVector GK_weights, double mean_time) {
  if (t_val <= 0) return 0.0;
  
  double sum_res = 0.0;
  double half_t = t_val / 2.0;
  int n_nodes = GK_nodes.size();
  
  // W_val[0] 是 age, W_val[1] 是 drug
  double mu_c = beta_val[0] + beta_val[1]*W_val[0] + beta_val[2]*W_val[1] + b_val[0];
  double mu_1 = beta_val[3] + b_val[1];
  
  for(int k = 0; k < n_nodes; ++k) {
      double u = half_t * GK_nodes[k] + half_t;
      
      double m_u = mu_c + mu_1 * (u - mean_time);
      double m_prime_u = mu_1;
      double m_int_u = mu_c * u + mu_1 * (0.5 * u * u - mean_time * u);

      double assoc_term = alpha_val[0]*m_u + alpha_val[1]*m_prime_u + alpha_val[2]*m_int_u;
      double h_u = lam * rho * pow(u, rho - 1.0) * exp(gamma_val[0]*W_val[0] + gamma_val[1]*W_val[1] + assoc_term);
      
      sum_res += GK_weights[k] * h_u;
  }
  return half_t * sum_res;
}
'

cat(">>> 正在主节点编译 C++ 积分函数...\n")
sourceCpp(code = cpp_code)  

# ========================================================
# 2. 并行核心与全局参数设置
# ========================================================
slurm_cores <- as.numeric(Sys.getenv("SLURM_NTASKS"))
if (is.na(slurm_cores)) {
  slurm_cores <- min(10, max(1, detectCores() - 1))
}
cl <- makeCluster(slurm_cores, outfile = "")
registerDoParallel(cl)
clusterExport(cl, "cpp_code")
clusterEvalQ(cl, {
  library(Rcpp)
  sourceCpp(code = cpp_code, cacheDir = tempdir()) 
})

set.seed(2026)
n_subj <- 500        
n_sim  <- 100         

beta_true <- c(1.5, 0.02, -0.3, 0.4) 
sigma_ald <- 0.5
gamma_true <- c(0.03, -0.1) 
gamma_shape <- 1.5 
alpha_true <- c(0.5, -0.2, 0.1) 
D_mat <- matrix(c(1, 0.5, 0.5, 1), 2, 2)

true_param_vec <- c("beta[1]" = 1.5, "beta[2]" = 0.02, "beta[3]" = -0.3, "beta[4]" = 0.4,
                    "gamma_surv[1]" = 0.03, "gamma_surv[2]" = -0.1, 
                    "alpha[1]" = 0.5, "alpha[2]" = -0.2, "alpha[3]" = 0.1, 
                    "sigma" = 0.5)

censoring_type <- "random" 
target_censor_rate <- 0.50
fixed_c_time <- 2.0 

GK.nodes <- c(-0.9491079, -0.7415312, -0.4058452, 0, 0.4058452, 0.7415312, 0.9491079)
GK.weights <- c(0.1294850, 0.2797054, 0.3818301, 0.4179592, 0.3818301, 0.2797054, 0.1294850)

time_windows <- data.frame( landmark_t = c(0.75, 1.0, 1.5), horizon_s  = c(1.5, 1.75, 2.0) )
target_P <- 100; target_Q <- 30; n_burn <- 50
prop_Sigma <- diag(c(0.01, 0.0005))

dir.create("jifen", showWarnings = FALSE)

# ========================================================
# 3. 外层大循环
# ========================================================
tau_values <- 0.25

for (current_tau in tau_values) {
  cat(sprintf("\n\n========================================================\n"))
  cat(sprintf(">>> 开始执行分位数 tau = %.2f 的模拟与预测...\n", current_tau))
  
  start_time <- Sys.time()
  folder_name <- sprintf("jifen/tau_%.2f", current_tau)
  dir.create(folder_name, showWarnings = FALSE, recursive = TRUE)
  
  k1 <- (1 - 2*current_tau) / (current_tau * (1 - current_tau))
  k2_sq <- 2 / (current_tau * (1 - current_tau))
  
  if (censoring_type == "fixed") {
    # 省略 Lambda 校准逻辑，直接给 lambda_true
    lambda_true <- 0.1
  } else {
    lambda_true <- 0.1 
  }
  
  results_list <- foreach(s = 1:n_sim, .options.RNG = 2026, 
                          .packages = c("MASS", "survival", "rjags", "coda", "GIGrvg", "Rcpp", "caret", "nlme", "dplyr", "pROC"), 
                          .export = c("GK.nodes", "GK.weights", "k1", "k2_sq", "prop_Sigma", 
                                      "time_windows", "folder_name", "current_tau", "lambda_true",
                                      "n_subj", "beta_true", "gamma_true", "alpha_true", "gamma_shape", 
                                      "sigma_ald", "D_mat", "censoring_type", "target_censor_rate", 
                                      "fixed_c_time", "target_P", "target_Q", "n_burn", "true_param_vec"), 
                          .noexport = "calc_cum_hazard_weibull_cpp") %dorng% {
                            
                            rALD <- function(n, sigma, tau) {
                              e <- rexp(n, 1/sigma); v <- rnorm(n, 0, 1)
                              return(k1 * e + sqrt(2 / (tau * (1 - tau))) * sqrt(sigma * e) * v)
                            }
                            
                            # --- 1. 模拟上帝视角 (DGP) ---
                            age <- runif(n_subj, 30, 70); drug <- rbinom(n_subj, 1, 0.5)
                            b <- mvrnorm(n_subj, mu = c(0, 0), Sigma = D_mat)
                            age_z_true <- (age - 50) / (40 / sqrt(12)) 
                            W_true <- cbind(age_z_true, drug)
                            
                            t_true <- numeric(n_subj)
                            for (i in 1:n_subj) {
                              u_val <- runif(1)
                              target_func <- function(t_val) {
                                # 注意：DGP 阶段 mean_time = 0.0
                                calc_cum_hazard_weibull_cpp(t_val, lambda_true, gamma_shape, alpha_true, beta_true, gamma_true, W_true[i,], b[i,], GK.nodes, GK.weights, 0.0) - (-log(u_val))
                              }
                              t_true[i] <- tryCatch({ uniroot(target_func, interval = c(1e-6, 150))$root }, error = function(e) { return(150) })
                            }
                            
                            if (censoring_type == "random") {
                              find_c_emp <- function(cm) { mean(pmin(t_true, cm) / cm) - target_censor_rate }
                              c_max_opt <- tryCatch({ uniroot(find_c_emp, interval = c(0.01, 150), extendInt = "yes")$root }, error = function(e) { return(150) })
                              c_max_opt <- min(max(c_max_opt, 0.01), 1000) 
                              c_time <- runif(n_subj, 0, c_max_opt) 
                            } else {
                              c_time <- rep(fixed_c_time, n_subj) 
                            }
                            
                            years <- pmin(t_true, c_time)
                            status <- as.numeric(t_true <= c_time)
                            
                            long_list <- list()
                            for (i in 1:n_subj) {
                              v_times <- seq(0, max(years), by = 0.2)
                              v_times <- v_times[v_times <= years[i]]
                              if(length(v_times) == 0) v_times <- 0
                              mu_long <- beta_true[1] + beta_true[2]*age_z_true[i] + beta_true[3]*drug[i] + beta_true[4]*v_times + b[i, 1] + b[i, 2]*v_times
                              long_list[[i]] <- data.frame(id = i, time = v_times, Y = mu_long + rALD(length(v_times), sigma_ald, current_tau))
                            }
                            df_long <- do.call(rbind, long_list)
                            df_surv <- data.frame(id = 1:n_subj, years = years, status = status, age = age, drug = drug, age_z_true = age_z_true)
                            
                            # --- 2. 数据划分与中心化 ---
                            train_idx <- as.numeric(caret::createDataPartition(as.factor(df_surv$status), p = 0.75, list = FALSE))
                            test_ids  <- setdiff(1:n_subj, train_idx)
                            
                            df_surv_train <- df_surv[df_surv$id %in% train_idx, ]
                            df_surv_test  <- df_surv[df_surv$id %in% test_ids, ]
                            df_long_train <- df_long[df_long$id %in% train_idx, ]
                            
                            df_surv_train$age_z <- df_surv_train$age_z_true
                            df_surv_test$age_z  <- df_surv_test$age_z_true
                            df_long_train$age_z <- df_surv_train$age_z[match(df_long_train$id, df_surv_train$id)]
                            df_long_train$drug  <- df_surv_train$drug[match(df_long_train$id, df_surv_train$id)]
                            
                            # [修改] 提取训练集的时间中心点
                            train_time_mean <- mean(df_long_train$time, na.rm = TRUE)
                            df_long_train$time_c <- df_long_train$time - train_time_mean
                            
                            df_surv_train$id_jags <- 1:nrow(df_surv_train)
                            df_long_train$id_jags <- match(df_long_train$id, df_surv_train$id)
                            n_train <- nrow(df_surv_train)
                            
                            num_meas_train <- as.numeric(table(factor(df_long_train$id_jags, levels = 1:n_train)))
                            Y_mat <- matrix(NA, n_train, max(num_meas_train))
                            time_c_mat <- matrix(0, n_train, max(num_meas_train)) 
                            
                            for(i in 1:n_train) {
                              idx <- which(df_long_train$id_jags == i)
                              if(length(idx) > 0) {
                                Y_mat[i, 1:length(idx)] <- df_long_train$Y[idx]
                                time_c_mat[i, 1:length(idx)] <- df_long_train$time_c[idx] 
                              }
                            }
                            
                            # [修改] 使用 time_c 获取初始值
                            fit_lme <- try(nlme::lme(Y ~ age_z + drug + time_c, random = ~ time_c | id_jags,
                                                     data = df_long_train, control = nlme::lmeControl(opt = "optim")), silent = TRUE)
                            init_beta <- if(!inherits(fit_lme, "try-error")) as.numeric(nlme::fixef(fit_lme)) else rnorm(4, 0, 0.1)
                            
                            fit_surv <- try(survival::survreg(Surv(years, status) ~ age_z + drug, data = df_surv_train, dist = "weibull"), silent = TRUE)
                            if(!inherits(fit_surv, "try-error")) {
                              init_gamma <- -as.numeric(coef(fit_surv)[2:3]) / fit_surv$scale
                              init_rho <- 1 / fit_surv$scale
                              init_log_lam <- -as.numeric(coef(fit_surv)[1]) / fit_surv$scale
                            } else {
                              init_gamma <- rnorm(2, 0, 0.1); init_rho <- 1.0; init_log_lam <- log(0.01)
                            }
                            
                            inits_func <- function(chain_id) {
                              list(
                                beta = init_beta + rnorm(4, 0, 0.05),
                                gamma_surv = init_gamma+ rnorm(2, 0, 0.05),
                                alpha = c(runif(1, 0.1, 0.5), rnorm(2, 0, 0.1)),
                                log_lambda = init_log_lam + rnorm(1, 0, 0.05), 
                                rho = init_rho * exp(rnorm(1, 0, 0.05))
                              )
                            }
                            
                            inits_list <- list(inits_func(1), inits_func(2))
                            jags_data_train <- list(
                              N_subj = n_train, num_meas = num_meas_train, Y = Y_mat, 
                              time_c = time_c_mat, mean_time = train_time_mean, # 传入 JAGS             
                              years = df_surv_train$years, delta = df_surv_train$status, 
                              age = df_surv_train$age_z, drug = df_surv_train$drug, tau_quant = current_tau, 
                              R.mat = matrix(c(1, 0, 0, 0.1), 2, 2),  k.wishart = 3, zeros = rep(0, n_train),
                              GK.nodes = GK.nodes, GK.weights = GK.weights
                            )
                            
                            # --- 3. JAGS 运行 ---
                            res <- tryCatch({
                              # [修改] 提高迭代与 Burn-in 压低 R-hat
                              m <- jags.model("jm_sim_centered.jags", data = jags_data_train, inits = inits_list, n.chains = 2, n.adapt = 15000, quiet = TRUE)
                              update(m, 50000, progress.bar = "none") 
                              
                              var_names_to_monitor <- c(names(true_param_vec), "D_inv", "lambda", "rho") 
                              samples <- coda.samples(m, variable.names = var_names_to_monitor, n.iter = 75000, thin = 150)
                              
                              post_mat_full <- as.matrix(samples) 
                              actual_P <- min(nrow(post_mat_full), target_P) 
                              post_mat <- post_mat_full[sample(1:nrow(post_mat_full), actual_P), ]
                              
                              summ <- summary(samples)
                              rhat <- tryCatch(gelman.diag(samples, multivariate = FALSE)$psrf[, 1], error = function(e) rep(NA, ncol(post_mat)))
                              
                              current_estimates <- data.frame(
                                param = rownames(summ$statistics), mean_est = summ$statistics[, "Mean"],
                                sd_est = summ$statistics[, "SD"], lower = summ$quantiles[, "2.5%"], upper = summ$quantiles[, "97.5%"], r_hat = rhat, sim_id = s
                              )
                              
                              # --- 4. 预测环节 ---
                              all_windows_pred_list <- list() 
                              for (w in 1:nrow(time_windows)) {
                                current_t <- time_windows$landmark_t[w]
                                current_s <- time_windows$horizon_s[w]
                                
                                df_surv_test_sub <- df_surv[df_surv$id %in% test_ids & df_surv$years > current_t, ]
                                if (nrow(df_surv_test_sub) == 0) next 
                                
                                pred_results <- data.frame(sim_id = s, window_t = current_t, window_s = current_s, id = df_surv_test_sub$id, 
                                                           true_years = df_surv_test_sub$years, event = df_surv_test_sub$status, pi_pred = NA, pi_true = NA)
                                
                                for (idx in 1:nrow(df_surv_test_sub)) {
                                  new_id <- df_surv_test_sub$id[idx]
                                  history_Y <- df_long[df_long$id == new_id & df_long$time <= current_t, ]
                                  Y_obs <- history_Y$Y; 
                                  t_obs <- history_Y$time
                                  t_obs_c <- t_obs - train_time_mean # [修改]
                                  
                                  age_i <- df_surv_test_sub$age_z[idx]; drug_i <- df_surv_test_sub$drug[idx]
                                  age_true_i <- df_surv_test_sub$age_z_true[idx]
                                  n_i <- length(Y_obs)
                                  
                                  b_true_i <- b[new_id, ]
                                  # DGP 真实值的 mean_time 为 0.0
                                  H_true_land <- calc_cum_hazard_weibull_cpp(current_t, lambda_true, gamma_shape, alpha_true, beta_true, gamma_true, c(age_true_i, drug_i), b_true_i, GK.nodes, GK.weights, 0.0)
                                  H_true_horiz <- calc_cum_hazard_weibull_cpp(current_s, lambda_true, gamma_shape, alpha_true, beta_true, gamma_true, c(age_true_i, drug_i), b_true_i, GK.nodes, GK.weights, 0.0)
                                  pred_results$pi_true[idx] <- exp(-(H_true_horiz - H_true_land))
                                  
                                  surv_prob_Q <- numeric(actual_P * target_Q); counter <- 1
                                  b_curr <- c(0, 0); e_curr <- rep(1, n_i)
                                  
                                  for (p in 1:actual_P) {
                                    beta_p <- post_mat[p, c("beta[1]", "beta[2]", "beta[3]", "beta[4]")]
                                    gamma_surv_p <- post_mat[p, c("gamma_surv[1]", "gamma_surv[2]")]
                                    alpha_p <- post_mat[p, c("alpha[1]", "alpha[2]", "alpha[3]")]
                                    sig_p <- post_mat[p, "sigma"]; lambda_p <- post_mat[p, "lambda"]; rho_p <- post_mat[p, "rho"] 
                                    
                                    d11 <- post_mat[p, grep("D_inv\\[1, ?1\\]", colnames(post_mat))]
                                    d21 <- post_mat[p, grep("D_inv\\[2, ?1\\]", colnames(post_mat))]
                                    d12 <- post_mat[p, grep("D_inv\\[1, ?2\\]", colnames(post_mat))]
                                    d22 <- post_mat[p, grep("D_inv\\[2, ?2\\]", colnames(post_mat))]
                                    Tau_b_p <- matrix(c(d11, d21, d12, d22), 2, 2)
                                    
                                    for (q_iter in 1:(target_Q + n_burn)) {
                                      if (n_i > 0) {
                                        # 纵向使用 t_obs_c
                                        mu_ij <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*drug_i + beta_p[4]*t_obs_c + b_curr[1] + b_curr[2]*t_obs_c
                                        gig_chi <- pmax((Y_obs - mu_ij)^2 / (k2_sq * sig_p), 1e-6)
                                        e_curr <- rgig(n = n_i, lambda = 0.5, chi = gig_chi, psi = (k1^2 + 2*k2_sq) / (k2_sq * sig_p))
                                      }
                                      
                                      calc_log_post_b <- function(b_val) {
                                        log_prior <- -0.5 * as.numeric(t(b_val) %*% Tau_b_p %*% b_val)
                                        log_lik_long <- 0
                                        if (n_i > 0) {
                                          mu_val <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*drug_i + beta_p[4]*t_obs_c + b_val[1] + b_val[2]*t_obs_c
                                          log_lik_long <- sum( - (Y_obs - mu_val - k1 * e_curr)^2 / (2 * k2_sq * sig_p * e_curr) )
                                        }
                                        # 传入 train_time_mean 
                                        cum_H_landmark <- calc_cum_hazard_weibull_cpp(current_t, lambda_p, rho_p, alpha_p, beta_p, gamma_surv_p, c(age_i, drug_i), b_val, GK.nodes, GK.weights, train_time_mean)
                                        return(log_prior + log_lik_long - cum_H_landmark)
                                      }
                                      
                                      log_post_curr <- calc_log_post_b(b_curr)
                                      b_cand <- b_curr + MASS::mvrnorm(1, mu = c(0,0), Sigma = prop_Sigma)
                                      if (calc_log_post_b(b_cand) - log_post_curr > log(runif(1))) b_curr <- b_cand
                                      
                                      if (q_iter > n_burn) {
                                        H_land <- calc_cum_hazard_weibull_cpp(current_t, lambda_p, rho_p, alpha_p, beta_p, gamma_surv_p, c(age_i, drug_i), b_curr, GK.nodes, GK.weights, train_time_mean)
                                        H_horiz <- calc_cum_hazard_weibull_cpp(current_s, lambda_p, rho_p, alpha_p, beta_p, gamma_surv_p, c(age_i, drug_i), b_curr, GK.nodes, GK.weights, train_time_mean)
                                        surv_prob_Q[counter] <- exp(-(H_horiz - H_land))
                                        counter <- counter + 1
                                      }
                                    } 
                                  } 
                                  pred_results$pi_pred[idx] <- mean(surv_prob_Q, na.rm = TRUE)
                                }
                                all_windows_pred_list[[w]] <- pred_results
                              } 
                              
                              final_pred_results <- do.call(rbind, all_windows_pred_list)
                              
                              sim_metrics <- final_pred_results %>%
                                filter(!is.na(pi_pred)) %>%
                                filter(!(true_years <= window_s & event == 0)) %>%
                                mutate(survived_s = ifelse(true_years > window_s, 1, 0)) %>%
                                group_by(window_t, window_s) %>%
                                summarise(
                                  sim_id = s, N_Test = n(),
                                  brier_pred = mean((pi_pred - survived_s)^2),
                                  auc_pred = as.numeric(pROC::roc(survived_s, pi_pred, direction="<", quiet=TRUE)$auc),
                                  brier_true = mean((pi_true - survived_s)^2),
                                  auc_true = as.numeric(pROC::roc(survived_s, pi_true, direction="<", quiet=TRUE)$auc),
                                  .groups = "drop"
                                )
                              
                              list(
                                estimates = current_estimates, 
                                predictions = final_pred_results,
                                debug_data = list(df_long = df_long, df_surv = df_surv),
                                metrics = sim_metrics, censor_rate = mean(df_surv_train$status == 0),
                                censor_times = c_time, event_status = status            
                              )
                            }, error = function(e) {
                              cat(sprintf("\n[Worker Error] Sim %d Failed: %s\n", s, conditionMessage(e)))
                              return(NULL)
                            })
                            gc() 
                            return(res)
                          }
  
  run_time <- Sys.time() - start_time
  valid_res <- Filter(Negate(is.null), results_list)
  
  if (length(valid_res) == 0) next
  
  avg_censor_rate <- mean(sapply(valid_res, `[[`, "censor_rate"))
  all_c_times_matrix <- do.call(rbind, lapply(valid_res, `[[`, "censor_times"))
  all_status_matrix <- do.call(rbind, lapply(valid_res, `[[`, "event_status"))
  all_estimates_df <- do.call(rbind, lapply(valid_res, `[[`, "estimates"))
  all_predictions_df <- do.call(rbind, lapply(valid_res, `[[`, "predictions"))
  all_metrics_df <- do.call(rbind, lapply(valid_res, `[[`, "metrics"))
  
  all_df_surv <- do.call(rbind, lapply(seq_along(valid_res), function(i) {
    df <- valid_res[[i]]$debug_data$df_surv; df$sim_id <- valid_res[[i]]$estimates$sim_id[1]; return(df)
  }))
  all_df_long <- do.call(rbind, lapply(seq_along(valid_res), function(i) {
    df <- valid_res[[i]]$debug_data$df_long; df$sim_id <- valid_res[[i]]$estimates$sim_id[1]; return(df)
  }))
  
  rdata_filename <- sprintf("composite_results_tau_25.RData", current_tau)
  save(all_estimates_df, avg_censor_rate, all_c_times_matrix, all_status_matrix,all_metrics_df,
       all_predictions_df, all_df_long, all_df_surv, run_time, file = rdata_filename)
}

stopCluster(cl)