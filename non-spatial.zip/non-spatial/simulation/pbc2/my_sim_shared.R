library(MASS)
library(survival)
library(rjags)
load.module("glm")
library(doParallel)
library(foreach)
library(doRNG)
library(GIGrvg)
library(Rcpp)
library(nlme)
library(caret)

# ========================================================
# 0. 定义 C++ 极速累积风险函数 (无需积分！)
# ========================================================
cpp_code_shared <- '
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double calc_cum_hazard_shared_cpp(double t_val, double lam, double rho, NumericVector alpha_val, NumericVector gamma_val, NumericVector W_val, NumericVector b_val) {
  if (t_val <= 0) return 0.0;
  
  // eta 包含协变量效应与随机效应
  double eta_surv = gamma_val[0]*W_val[0] + gamma_val[1]*W_val[1] + alpha_val[0]*b_val[0] + alpha_val[1]*b_val[1];
  
  // 返回 Weibull 的解析累积风险 H(t) = lambda * t^rho * exp(eta)
  return lam * pow(t_val, rho) * exp(eta_surv);
}
'
cat(">>> 正在主节点编译 C++ 函数...\n")
sourceCpp(code = cpp_code_shared)


# ========================================================
# 1. 全局数据与参数设置
# ========================================================
set.seed(2026)
n_subj <- 500
n_sim <- 100
beta_true <- c(1.5, 0.02, -0.3, 0.4) 
sigma_ald <- 0.5
gamma_true <- c(0.03, -0.1)  
gamma_shape <- 1.5 
alpha_true <- c(0.8, -0.2) 
D_mat <- matrix(c(1, 0.5, 0.5, 1), 2, 2)

censoring_type <- "random" 
target_censor_rate <- 0.50
fixed_c_time <- 2.0 
true_param_vec <- c(
  "beta[1]" = 1.5, "beta[2]" = 0.02, "beta[3]" = -0.3, "beta[4]" = 0.4,
  "gamma[1]" = 0.03, "gamma[2]" = -0.1,
  "alpha[1]" = 0.8, "alpha[2]" = -0.2,
  "lambda" = 0.1, "gamma_shape" = 1.5, "sigma" = 0.5
)

if (censoring_type == "fixed") {
  cat(sprintf(">>> 正在校准 lambda 以匹配 %.0f%% 删失率...\n", target_censor_rate * 100))
  N_calib <- 5000 
  age_calib <- runif(N_calib, 30, 70) 
  drug_calib <- rbinom(N_calib, 1, 0.5)
  W_calib <- cbind(age_calib - mean(age_calib), drug_calib)
  b_calib <- mvrnorm(N_calib, mu = c(0, 0), Sigma = D_mat)
  eta_calib <- as.vector(W_calib %*% gamma_true + b_calib[, 1] * alpha_true[1] + b_calib[, 2] * alpha_true[2])
  find_lambda <- function(lam) mean(exp(-lam * (fixed_c_time^gamma_shape) * exp(eta_calib))) - target_censor_rate
  lambda_true <- uniroot(find_lambda, interval = c(1e-5, 10))$root
  cat(sprintf(">>> 校准完成，真实 lambda = %.5f\n", lambda_true))
} else {
  lambda_true <- 0.1 
}

time_windows <- data.frame(
  landmark_t = c(0.75, 1.0, 1.5),  
  horizon_s  = c(1.5, 1.75, 2.0)   
)
target_P <- 200; target_Q <- 100; n_burn <- 50

# 【核心修复】全局定义 MH 抽样的提议协方差矩阵
# 大幅缩减随机游走的步长，确保 MH 抽样器在预测阶段能被有效接受
prop_Sigma <- diag(c(0.01, 0.0005))

# ========================================================
# 2. 超算集群并行配置 (核心数获取与 C++ 独立缓存)
# ========================================================
slurm_cores <- as.numeric(Sys.getenv("SLURM_NTASKS"))
if (is.na(slurm_cores)) {
  slurm_cores <- 8
}
cat(sprintf(">>> CSF 集群分配的并行核心数为: %d\n", slurm_cores))

cl <- makeCluster(slurm_cores, outfile = "") 
registerDoParallel(cl)
dir.create("share_effect_random", showWarnings = FALSE)

cat(">>> 正在向并行节点导出 C++ 代码并避免缓存冲突...\n")
clusterExport(cl, "cpp_code_shared")
clusterEvalQ(cl, {
  library(Rcpp)
  sourceCpp(code = cpp_code_shared, cacheDir = tempdir()) 
})


# ========================================================
# 3. 开始主循环 (针对多个 tau 分别模拟)
# ========================================================
tau_values <- c(0.25, 0.50, 0.75)

for (current_tau in tau_values) {
  
  cat(sprintf("\n\n========================================================\n"))
  cat(sprintf(">>> 开始执行分位数 tau = %.2f 的模拟与预测...\n", current_tau))
  cat(sprintf("========================================================\n"))
  
  start_time <- Sys.time()
  
  k1 <- (1 - 2*current_tau) / (current_tau * (1 - current_tau))
  k2_sq <- 2 / (current_tau * (1 - current_tau))
  
  # --- 内层并行模拟循环 ---
  results_list <- foreach(s = 1:n_sim, .options.RNG = 2026, 
                          .packages = c("MASS", "survival", "rjags", "coda", "GIGrvg", "Rcpp", "caret", "nlme", "dplyr", "pROC"), # 增加后面两个
                          # 【修复】清理了重复导出，直接在这里声明
                          .export = c("k1", "k2_sq", "prop_Sigma", "time_windows", "current_tau", "lambda_true",
                                      "n_subj", "beta_true", "gamma_true", "alpha_true", "gamma_shape", 
                                      "sigma_ald", "D_mat", "censoring_type", "target_censor_rate", 
                                      "fixed_c_time", "target_P", "target_Q", "n_burn", "true_param_vec"), 
                          .noexport = "calc_cum_hazard_shared_cpp") %dorng% {
                            
                            rALD <- function(n, sigma, tau) {
                              e <- rexp(n, 1/sigma); v <- rnorm(n, 0, 1)
                              return(k1 * e + sqrt(2 / (tau * (1 - tau))) * sqrt(sigma * e) * v)
                            }
  
                            # ========================================================
                            # 1. 模拟上帝视角 (DGP)：生成绝对真实的生命轨迹
                            # ========================================================
                            age <- runif(n_subj, 30, 70)
                            drug <- rbinom(n_subj, 1, 0.5)
                            b <- mvrnorm(n_subj, mu = c(0, 0), Sigma = D_mat)
                            
                            age_z_true <- (age - 50) / (40 / sqrt(12)) 
                            W_true <- cbind(age_z_true, drug)
                            
                            t_true <- numeric(n_subj)
                            for (i in 1:n_subj) {
                              u_val <- runif(1)
                              target_func <- function(t_val) {
                                calc_cum_hazard_shared_cpp(t_val, lambda_true, gamma_shape, alpha_true, gamma_true, W_true[i,], b[i,]) - (-log(u_val))
                              }
                              t_true[i] <- tryCatch({ 
                                uniroot(target_func, interval = c(1e-6, 150))$root 
                              }, error = function(e) { return(150) })
                            }
                            
                            if (censoring_type == "random") {
                              find_c_emp <- function(cm) { mean(pmin(t_true, cm) / cm) - target_censor_rate }
                              c_max_opt <- tryCatch({ uniroot(find_c_emp, interval = c(0.01, 150), extendInt = "yes")$root }, error = function(e) { return(150) })
                              c_max_opt <- min(max(c_max_opt, 0.01), 1000) 
                              c_time <- runif(n_subj, 0, c_max_opt) 
                            } else {
                              c_time <- rep(fixed_c_time, n_subj) 
                            }
                            
                            years <- pmin(t_true, c_time)
                            status <- as.numeric(t_true <= c_time)
                            
                            long_list <- list()
                            for (i in 1:n_subj) {
                              v_times <- seq(0, max(years), by = 0.2)
                              v_times <- v_times[v_times <= years[i]]
                              if(length(v_times) == 0) v_times <- 0
                              mu_long <- beta_true[1] + beta_true[2]*age_z_true[i] + beta_true[3]*drug[i] + beta_true[4]*v_times + b[i, 1] + b[i, 2]*v_times
                              long_list[[i]] <- data.frame(id = i, time = v_times, Y = mu_long + rALD(length(v_times), sigma_ald, current_tau))
                            }
                            df_long <- do.call(rbind, long_list)
                            
                            # 暴露给分析流程的数据框，包含 age_z_true
                            df_surv <- data.frame(id = 1:n_subj, years = years, status = status, age = age, drug = drug, age_z_true = age_z_true)
                            
                            # ========================================================
                            # 2. 真实数据分析管线：先分割，再依靠训练集标准化
                            # ========================================================
                            # ========================================================
                            # 2. 模拟数据分析管线：保留分层抽样，禁用重新标准化
                            # ========================================================
                            # 使用 caret 保证训练/测试集的删失率完全一致
                            train_idx <- as.numeric(caret::createDataPartition(as.factor(df_surv$status), p = 0.75, list = FALSE))
                            test_ids  <- setdiff(1:n_subj, train_idx)
                            
                            df_surv_train <- df_surv[df_surv$id %in% train_idx, ]
                            df_surv_test  <- df_surv[df_surv$id %in% test_ids, ]
                            df_long_train <- df_long[df_long$id %in% train_idx, ]
                            
                            # ⚠️ 核心修改：模拟研究中，直接使用上帝视角的 age_z_true
                            # 绝对不能用 train_age_mean 和 sd 重新做局部标准化！
                            df_surv_train$age_z <- df_surv_train$age_z_true
                            df_surv_test$age_z  <- df_surv_test$age_z_true
                            
                            # 将 age_z 和 drug 同步映射到长格式数据中
                            df_long_train$age_z <- df_surv_train$age_z[match(df_long_train$id, df_surv_train$id)]
                            df_long_train$drug  <- df_surv_train$drug[match(df_long_train$id, df_surv_train$id)]
                            
                            # 为 JAGS 重新编排连续的内部 ID
                            df_surv_train$id_jags <- 1:nrow(df_surv_train)
                            df_long_train$id_jags <- match(df_long_train$id, df_surv_train$id)
                            n_train <- nrow(df_surv_train)
                            
                            # ========================================================
                            # 3. 稳健的 JAGS 数据矩阵构建
                            # ========================================================
                            num_meas_train <- as.numeric(table(factor(df_long_train$id_jags, levels = 1:n_train)))
                            
                            Y_mat <- matrix(NA, n_train, max(num_meas_train))
                            time_mat <- matrix(0, n_train, max(num_meas_train)) 
                            
                            for(i in 1:n_train) {
                              idx <- which(df_long_train$id_jags == i)
                              if(length(idx) > 0) {
                                Y_mat[i, 1:length(idx)] <- df_long_train$Y[idx]
                                time_mat[i, 1:length(idx)] <- df_long_train$time[idx] 
                              }
                            }
                            
                            # 这里的 jags_data_train 构建逻辑不需要变，因为里面的 df_surv_train$age_z 已经是真实的 Z-score 了
                            
                            fit_lme <- try(nlme::lme(Y ~ age_z + drug + time, random = ~ time | id_jags,
                                                     data = df_long_train, control = nlme::lmeControl(opt = "optim")), silent = TRUE)
                            init_beta <- if(!inherits(fit_lme, "try-error")) as.numeric(nlme::fixef(fit_lme)) else rnorm(4, 0, 0.1)
                            fit_surv <- try(survival::survreg(Surv(years, status) ~ age_z + drug, 
                                  data = df_surv_train, dist = "weibull"), silent = TRUE)
                            if(!inherits(fit_surv, "try-error")) {
                              init_gamma <- -as.numeric(coef(fit_surv)[2:3]) / fit_surv$scale
                              init_rho <- 1 / fit_surv$scale
                              init_log_lam <- -as.numeric(coef(fit_surv)[1]) / fit_surv$scale
                            } else {
                              init_gamma <- rnorm(2, 0, 0.1); init_rho <- 1.0; init_log_lam <- log(0.01)
                            }
                

                            inits_func <- function(chain_id) {
                        
                              list(
                                beta = init_beta + rnorm(4, 0, 0.05),
                                gamma = init_gamma  + rnorm(2, 0, 0.05),
                                alpha = c(runif(1, 0.1, 0.5), rnorm(1, 0, 0.1)),
                                log_lambda = init_log_lam + rnorm(1, 0, 0.05), 
                                gamma_shape = init_rho * exp(rnorm(1, 0, 0.05))
                              )
                            }
                            inits_list <- list(inits_func(1), inits_func(2))
                            
                            jags_data_train <- list(
                              N_subj = n_train, 
                              num_meas = num_meas_train, 
                              Y = Y_mat, 
                              time = time_mat,             
                              years = df_surv_train$years, 
                              delta = df_surv_train$status, 
                              age = df_surv_train$age_z, 
                              drug = df_surv_train$drug, 
                              tau_quant = current_tau, 
                              R.mat = matrix(c(1, 0, 0, 0.1), 2, 2),
                              k.wishart = 3, 
                              zeros = rep(0, n_train)
                            )
                            
                            res <- tryCatch({
                              m <- jags.model("jm_ald_weibull_shared.jags", data = jags_data_train, inits = inits_list, n.chains = 2, n.adapt = 30000, quiet = TRUE) 
                              update(m, 60000, progress.bar = "none")
                              
                              var_names_to_monitor <- c(names(true_param_vec), "D_inv") 
                              samples <- coda.samples(m, variable.names = var_names_to_monitor, n.iter = 50000, thin = 100)
                              post_mat_full <- as.matrix(samples) 
                              
                              actual_P <- min(nrow(post_mat_full), target_P) 
                              post_mat <- post_mat_full[sample(1:nrow(post_mat_full), actual_P), ]
                              
                              summ <- summary(samples)
                              rhat <- tryCatch(gelman.diag(samples, multivariate = FALSE)$psrf[, 1], error = function(e) rep(NA, nrow(summ$statistics)))
                              current_estimates <- data.frame(
                                param = rownames(summ$statistics), mean_est = summ$statistics[, "Mean"],
                                sd_est = summ$statistics[, "SD"], lower = summ$quantiles[, "2.5%"], upper = summ$quantiles[, "97.5%"],
                                r_hat = rhat, sim_id = s
                              )
                              safe_file <- sprintf("share_effect_random/share_effect_random_tau_%.2f_sim_%03d.csv", current_tau, s)
                              tryCatch({ write.csv(current_estimates, file = safe_file, row.names = FALSE) }, error = function(e) {})
                              trace_to_keep <- if(s %in% c(1, 50, 100)) list(sim_id = s, samples = samples) else NULL
                              
                              # ========================================================
                              # --- 动态预测 (C++ 提速版) ---
                              # ========================================================
                              all_windows_pred_list <- list() 
                              
                              for (w in 1:nrow(time_windows)) {
                                current_t <- time_windows$landmark_t[w]
                                current_s <- time_windows$horizon_s[w]
                                
                                df_surv_test <- df_surv[df_surv$id %in% test_ids & df_surv$years > current_t, ]
                                if (nrow(df_surv_test) == 0) next 
                                
                                pred_results <- data.frame(
                                  sim_id = s, window_t = current_t, window_s = current_s,  
                                  id = df_surv_test$id, true_years = df_surv_test$years, event = df_surv_test$status, pi_pred = NA, pi_true = NA
                                )
                                
                                for (idx in 1:nrow(df_surv_test)) {
                                  new_id <- df_surv_test$id[idx]
                                  history_Y <- df_long[df_long$id == new_id & df_long$time <= current_t, ]
                                  
                                  Y_obs <- history_Y$Y; t_obs <- history_Y$time
                                  age_i <- df_surv_test$age_z[idx]; drug_i <- df_surv_test$drug[idx]
                                  age_true_i <- df_surv_test$age_z_true[idx] 
                                  n_i <- length(Y_obs)
                                  
                                  # --- 真实 Oracle 概率 ---
                                  b_true_i <- b[new_id, ] 
                                  eta_true <- gamma_true[1]*age_true_i + gamma_true[2]*drug_i + alpha_true[1]*b_true_i[1] + alpha_true[2]*b_true_i[2]
                                  pred_results$pi_true[idx] <- exp(-lambda_true * (current_s^gamma_shape - current_t^gamma_shape) * exp(eta_true))
                                  
                                  # --- MH-within-Gibbs ---
                                  surv_prob_Q <- numeric(actual_P * target_Q)
                                  counter <- 1
                                  b_curr <- c(0, 0); e_curr <- rep(1, n_i)
                                  
                                  for (p in 1:actual_P) {
                                    beta_p <- post_mat[p, c("beta[1]", "beta[2]", "beta[3]", "beta[4]")]
                                    gamma_p <- post_mat[p, c("gamma[1]", "gamma[2]")]
                                    alpha_p <- post_mat[p, c("alpha[1]", "alpha[2]")]
                                    lam_p <- post_mat[p, "lambda"]; rho_p <- post_mat[p, "gamma_shape"]; sig_p <- post_mat[p, "sigma"]
                                    
                                    d11 <- post_mat[p, grep("D_inv\\[1, ?1\\]", colnames(post_mat))]
                                    d21 <- post_mat[p, grep("D_inv\\[2, ?1\\]", colnames(post_mat))]
                                    d12 <- post_mat[p, grep("D_inv\\[1, ?2\\]", colnames(post_mat))]
                                    d22 <- post_mat[p, grep("D_inv\\[2, ?2\\]", colnames(post_mat))]
                                    Tau_b_p <- matrix(c(d11, d21, d12, d22), 2, 2)
                                    
                                    for (q_iter in 1:(target_Q + n_burn)) {
                                      if (n_i > 0) {
                                        mu_ij <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*drug_i + beta_p[4]*t_obs + b_curr[1] + b_curr[2]*t_obs
                                        gig_chi <- pmax((Y_obs - mu_ij)^2 / (k2_sq * sig_p), 1e-6)
                                        e_curr <- rgig(n = n_i, lambda = 0.5, chi = gig_chi, psi = (k1^2 + 2*k2_sq) / (k2_sq * sig_p))
                                      }
                                      
                                      calc_log_post_b <- function(b_val) {
                                        log_prior <- -0.5 * as.numeric(t(b_val) %*% Tau_b_p %*% b_val)
                                        log_lik_long <- 0
                                        if (n_i > 0) {
                                          mu_val <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*drug_i + beta_p[4]*t_obs + b_val[1] + b_val[2]*t_obs
                                          log_lik_long <- sum( - (Y_obs - mu_val - k1 * e_curr)^2 / (2 * k2_sq * sig_p * e_curr) )
                                        }
                                        cum_H_landmark <- calc_cum_hazard_shared_cpp(current_t, lam_p, rho_p, alpha_p, gamma_p, c(age_i, drug_i), b_val)
                                        return(log_prior + log_lik_long - cum_H_landmark)
                                      }
                                      
                                      log_post_curr <- calc_log_post_b(b_curr)
                                      b_cand <- b_curr + MASS::mvrnorm(1, mu = c(0,0), Sigma = prop_Sigma)
                                      if (calc_log_post_b(b_cand) - log_post_curr > log(runif(1))) b_curr <- b_cand
                                      
                                      if (q_iter > n_burn) {
                                        H_land <- calc_cum_hazard_shared_cpp(current_t, lam_p, rho_p, alpha_p, gamma_p, c(age_i, drug_i), b_curr)
                                        H_horiz <- calc_cum_hazard_shared_cpp(current_s, lam_p, rho_p, alpha_p, gamma_p, c(age_i, drug_i), b_curr)
                                        surv_prob_Q[counter] <- exp(-(H_horiz - H_land))
                                        counter <- counter + 1
                                      }
                                    } 
                                  } 
                                  pred_results$pi_pred[idx] <- mean(surv_prob_Q, na.rm = TRUE)
                                } 
                                all_windows_pred_list[[w]] <- pred_results
                          } 
                          
                          final_pred_results <- do.call(rbind, all_windows_pred_list)
                          
                          # ========================================================
                          # 🔴 新增：在这里计算单次模拟的 AUC 和 Brier Score
                          # ========================================================
                          # 注意：这里直接借用你在 PBC2 中的 dplyr 写法，更简洁
                          sim_metrics <- final_pred_results %>%
                            filter(!is.na(pi_pred)) %>%
                            filter(!(true_years <= window_s & event == 0)) %>%
                            mutate(survived_s = ifelse(true_years > window_s, 1, 0)) %>%
                            group_by(window_t, window_s) %>%
                            summarise(
                              sim_id = s,
                              N_Test = n(),
                              brier_pred = mean((pi_pred - survived_s)^2),
                              auc_pred = as.numeric(pROC::roc(survived_s, pi_pred, direction="<", quiet=TRUE)$auc),
                              brier_true = mean((pi_true - survived_s)^2),
                              auc_true = as.numeric(pROC::roc(survived_s, pi_true, direction="<", quiet=TRUE)$auc),
                              .groups = "drop"
                            )
                          # ========================================================
                          
                          list(
                            estimates = current_estimates, 
                            predictions = final_pred_results,
                            debug_data = list(df_long = df_long, df_surv = df_surv),
                            metrics = sim_metrics,         # 🔴 新增：把指标加到返回的 list 中
                            debug_data = list(df_long = df_long, df_surv = df_surv),
                            censor_rate = mean(df_surv_train$status == 0),
                            trace = trace_to_keep,          
                            censor_times = c_time,         
                            event_status = status            
                          )
                            }, error = function(e) {
                              cat(sprintf("\n[DEBUG] Sim %d 致命报错信息: %s\n", s, e$message))
                              return(NULL)
                            })
                            gc() 
                            return(res)
                          }
  
  # --- 提取并保存当前 tau 的 RData ---
  run_time <- Sys.time() - start_time
  
  valid_res <- Filter(Negate(is.null), results_list)
  if (length(valid_res) == 0) {
    cat(sprintf("\n❌ 分位数 tau = %.2f 的所有并行任务均运行失败，未生成结果。\n", current_tau))
    next
  }
  
  actual_censor_rate <- sapply(valid_res, `[[`, "censor_rate")
  avg_censor_rate <- mean(actual_censor_rate)
  trace_samples <- Filter(Negate(is.null), lapply(valid_res, `[[`, "trace"))
  all_c_times_matrix <- do.call(rbind, lapply(valid_res, `[[`, "censor_times"))
  all_status_matrix <- do.call(rbind, lapply(valid_res, `[[`, "event_status"))
  all_estimates_df <- do.call(rbind, lapply(valid_res, `[[`, "estimates"))
  all_predictions_df <- do.call(rbind, lapply(valid_res, `[[`, "predictions"))
  all_metrics_df <- do.call(rbind, lapply(valid_res, `[[`, "metrics"))
  all_df_surv <- do.call(rbind, lapply(seq_along(valid_res), function(i) {
    df <- valid_res[[i]]$debug_data$df_surv
    df$sim_id <- valid_res[[i]]$predictions$sim_id[1] 
    return(df)
  }))
  
  all_df_long <- do.call(rbind, lapply(seq_along(valid_res), function(i) {
    df <- valid_res[[i]]$debug_data$df_long
    df$sim_id <- valid_res[[i]]$predictions$sim_id[1]
    return(df)
  }))
  
  rdata_filename <- sprintf("share_effect_random_sim_results_tau_%.2f.RData", current_tau)
  save(all_estimates_df, avg_censor_rate, all_c_times_matrix, all_status_matrix, all_metrics_df,
       trace_samples, all_predictions_df, all_df_surv, all_df_long, run_time, 
       file = rdata_filename)
  
  cat(sprintf("\n✅ 成功保存文件: %s\n", rdata_filename))
}

stopCluster(cl)
cat("\n🏁 所有 tau 分位数模拟全部执行完毕！\n")