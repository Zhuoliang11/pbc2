library(MASS)
library(survival)
library(rjags)
load.module("glm")
library(doParallel)
library(foreach)
library(doRNG)
library(GIGrvg)
library(Rcpp)  
library(nlme)
library(caret)
library(dplyr)
library(pROC)

# ========================================================
# 1. 动态生成 JAGS 模型文件
# ========================================================
cat("
  model {
    # 1. Longitudinal Part - ALD Implementation (Quantile Regression)
    prec_k2 <- (tau_quant * (1 - tau_quant)) / 2
    k1 <- (1 - 2 * tau_quant) / (tau_quant * (1 - tau_quant))
    
    for (i in 1:N_subj) {
      for (j in 1:num_meas[i]) {
        mu_long[i, j] <- beta[1] + beta[2]*age[i] + beta[3]*drug[i] + beta[4]*time[i, j] + 
                 b[i, 1] + b[i, 2]*time[i, j]
        Y[i, j] ~ dnorm(mu_long[i, j] + k1 * e[i, j], prec_long[i, j])
        prec_long[i, j] <- prec_k2 / max(sigma * e[i, j], 1e-7)
        e[i, j] ~ dexp(1 / sigma)
      }
    }

    # 2. Survival Part - Weibull & Current Value
    for (i in 1:N_subj) {
      b[i, 1:2] ~ dmnorm(mu.b[1:2], D_inv[1:2, 1:2])
      
      mu_T[i] <- beta[1] + beta[2]*age[i] + beta[3]*drug[i] + beta[4]*years[i]  + 
           b[i, 1] + b[i, 2]*years[i]
      
      hazard[i] <- lambda * rho * pow(max(years[i], 1e-7), rho - 1) * exp(gamma_surv[1]*age[i] + gamma_surv[2]*drug[i] + alpha * mu_T[i])
      
      for (k in 1:7) {
        u[i, k] <- (years[i] / 2) * GK.nodes[k] + (years[i] / 2)
        mu_u[i, k] <- beta[1] + beta[2]*age[i] + beta[3]*drug[i] + beta[4]*u[i, k] + 
              b[i, 1] + b[i, 2]*u[i, k]
        
        h_u[i, k] <- lambda * rho * pow(max(u[i, k], 1e-7), rho - 1) * exp(gamma_surv[1]*age[i] + gamma_surv[2]*drug[i] + alpha * mu_u[i, k])
      }
      cum_hazard[i] <- (years[i] / 2) * inprod(GK.weights[1:7], h_u[i, 1:7])
      
      logL[i] <- delta[i] * log(max(1e-10, hazard[i])) - cum_hazard[i]
      phi[i] <- -logL[i] + 100000
      zeros[i] ~ dpois(phi[i])
    }

    # 3. Priors
    for (p in 1:4) { beta[p] ~ dnorm(0, 0.01) }
    for (q in 1:2) { gamma_surv[q] ~ dnorm(0, 0.01) }
    alpha ~ dnorm(0, 0.01)
    
    tau.sigma ~ dgamma(0.01, 0.01)
    sigma <- 1 / tau.sigma 
    
    log_lambda ~ dnorm(0, 0.01) 
    lambda <- exp(log_lambda)
    rho ~ dunif(0.1, 5) 
    
    mu.b[1] <- 0; mu.b[2] <- 0
    D_inv[1:2, 1:2] ~ dwish(R.mat[1:2, 1:2], k.wishart)
    D[1:2, 1:2] <- inverse(D_inv[,])
  }
", file = "jm_ald_weibull_sim_current.jags")

# ========================================================
# 2. 定义 C++ 极速积分函数 (Rcpp)
# ========================================================
cpp_code <- '
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double calc_cum_hazard_weibull_cpp(double t_val, double lam, double rho, double alpha_val, NumericVector beta_val, NumericVector gamma_val, NumericVector W_val, NumericVector b_val, NumericVector GK_nodes, NumericVector GK_weights) {
  if (t_val <= 0) return 0.0;
  
  double sum_res = 0.0;
  double half_t = t_val / 2.0;
  int n_nodes = GK_nodes.size();
  
  for(int k = 0; k < n_nodes; ++k) {
      double u = half_t * GK_nodes[k] + half_t;
      double mu_u = beta_val[0] + beta_val[1]*W_val[0] + beta_val[2]*W_val[1] + beta_val[3]*u + b_val[0] + b_val[1]*u;
      double h_u = lam * rho * pow(u, rho - 1.0) * exp(gamma_val[0]*W_val[0] + gamma_val[1]*W_val[1] + alpha_val * mu_u);
      sum_res += GK_weights[k] * h_u;
  }
  
  return half_t * sum_res;
}
'

cat(">>> 正在主节点编译 C++ 积分函数...\n")
sourceCpp(code = cpp_code)  

# ========================================================
# 3. 并行核心设置 (CSF 集群合规)
# ========================================================
slurm_cores <- as.numeric(Sys.getenv("SLURM_NTASKS"))
if (is.na(slurm_cores)) {
  slurm_cores <- min(8, max(1, detectCores() - 1))
}
cat(sprintf(">>> 集群分配的并行核心数为: %d\n", slurm_cores))

cl <- makeCluster(slurm_cores, outfile = "")
registerDoParallel(cl)

cat(">>> 正在向各并行节点分发并编译 C++ 引擎...\n")
clusterExport(cl, "cpp_code")
clusterEvalQ(cl, {
  library(Rcpp)
  sourceCpp(code = cpp_code, cacheDir = tempdir()) 
})

# ========================================================
# 4. 全局参数设置
# ========================================================
set.seed(2026)
n_subj <- 500       
n_sim  <- 100         

beta_true <- c(1.5, 0.02, -0.3, 0.4) 
sigma_ald <- 0.5
gamma_true <- c(0.03, -0.1) 
gamma_shape <- 1.5 
alpha_true <- 0.5 
D_mat <- matrix(c(1, 0.5, 0.5, 1), 2, 2)

true_param_vec <- c("beta[1]" = 1.5, "beta[2]" = 0.02, "beta[3]" = -0.3, "beta[4]" = 0.4,
                    "gamma_surv[1]" = 0.03, "gamma_surv[2]" = -0.1, "alpha" = 0.5, "sigma" = 0.5)

censoring_type <- "random" 
target_censor_rate <- 0.50
fixed_c_time <- 2.0 

GK.nodes <- c(-0.9491079, -0.7415312, -0.4058452, 0, 0.4058452, 0.7415312, 0.9491079)
GK.weights <- c(0.1294850, 0.2797054, 0.3818301, 0.4179592, 0.3818301, 0.2797054, 0.1294850)

time_windows <- data.frame(
  landmark_t = c(0.75, 1.0, 1.5),  
  horizon_s  = c(1.5, 1.75, 2.0)   
)

target_P <- 100; target_Q <- 30; n_burn <- 50
prop_Sigma <- diag(c(0.01, 0.0005))

# ========================================================
# 5. 外层大循环：遍历 0.25, 0.50, 0.75
# ========================================================
tau_values <- c(0.25, 0.50, 0.75)

for (current_tau in tau_values) {
  
  cat(sprintf("\n\n========================================================\n"))
  cat(sprintf(">>> 开始执行分位数 tau = %.2f 的模拟与预测...\n", current_tau))
  cat(sprintf("========================================================\n"))
  
  start_time <- Sys.time()
  folder_name <- sprintf("current_value_random_%.2f", current_tau)
  dir.create(folder_name, showWarnings = FALSE, recursive = TRUE)
  
  k1 <- (1 - 2*current_tau) / (current_tau * (1 - current_tau))
  k2_sq <- 2 / (current_tau * (1 - current_tau))
  
  if (censoring_type == "fixed") {
    N_calib <- 5000 
    age_calib <- runif(N_calib, 30, 70); drug_calib <- rbinom(N_calib, 1, 0.5)
    W_calib <- cbind(age_calib - mean(age_calib), drug_calib)
    b_calib <- MASS::mvrnorm(N_calib, mu = c(0, 0), Sigma = D_mat)
    
    find_lambda_cv <- function(lam) {
      S_mean <- mean(sapply(1:N_calib, function(i) {
        H_2 <- calc_cum_hazard_weibull_cpp(fixed_c_time, lam, gamma_shape, alpha_true, beta_true, gamma_true, W_calib[i,], b_calib[i,], GK.nodes, GK.weights)
        exp(-H_2)
      }))
      return(S_mean - target_censor_rate)
    }
    lambda_true <- uniroot(find_lambda_cv, interval = c(1e-5, 5), extendInt = "yes")$root
  } else {
    lambda_true <- 0.1 
  }
  
  # --- 内层并行模拟循环 ---
  results_list <- foreach(s = 1:n_sim, .options.RNG = 2026, 
                          .packages = c("MASS", "survival", "rjags", "coda", "GIGrvg", "Rcpp", "caret", "nlme", "dplyr", "pROC"), 
                          .export = c("GK.nodes", "GK.weights", "k1", "k2_sq", "prop_Sigma", 
                                      "time_windows", "folder_name", "current_tau", "lambda_true",
                                      "n_subj", "beta_true", "gamma_true", "alpha_true", "gamma_shape", 
                                      "sigma_ald", "D_mat", "censoring_type", "target_censor_rate", 
                                      "target_P", "target_Q", "n_burn", "true_param_vec"), 
                          .noexport = "calc_cum_hazard_weibull_cpp") %dorng% {
                            
                            rALD <- function(n, sigma, tau) {
                              e <- rexp(n, 1/sigma); v <- rnorm(n, 0, 1)
                              return(k1 * e + sqrt(2 / (tau * (1 - tau))) * sqrt(sigma * e) * v)
                            }
  
                            # ========================================================
                            # 1. 模拟数据生成 (DGP)
                            # ========================================================
                            age <- runif(n_subj, 30, 70)
                            drug <- rbinom(n_subj, 1, 0.5)
                            b <- MASS::mvrnorm(n_subj, mu = c(0, 0), Sigma = D_mat)
                            
                            age_z_true <- (age - 50) / (40 / sqrt(12)) 
                            W_true <- cbind(age_z_true, drug)
                            
                            t_true <- numeric(n_subj)
                            for (i in 1:n_subj) {
                              u_val <- runif(1)
                              target_func <- function(t_val) {
                                calc_cum_hazard_weibull_cpp(t_val, lambda_true, gamma_shape, alpha_true, beta_true, gamma_true, W_true[i,], b[i,], GK.nodes, GK.weights) - (-log(u_val))
                              }
                              t_true[i] <- tryCatch({ 
                                uniroot(target_func, interval = c(1e-6, 150))$root 
                              }, error = function(e) { return(150) })
                            }
                            
                            if (censoring_type == "random") {
                              find_c_emp <- function(cm) { mean(pmin(t_true, cm) / cm) - target_censor_rate }
                              c_max_opt <- tryCatch({ uniroot(find_c_emp, interval = c(0.01, 150), extendInt = "yes")$root }, error = function(e) { return(150) })
                              c_max_opt <- min(max(c_max_opt, 0.01), 1000) 
                              c_time <- runif(n_subj, 0, c_max_opt) 
                            } else {
                              c_time <- rep(fixed_c_time, n_subj) 
                            }
                            
                            years <- pmin(t_true, c_time)
                            status <- as.numeric(t_true <= c_time)
                            
                            long_list <- list()
                            for (i in 1:n_subj) {
                              v_times <- seq(0, max(years), by = 0.2)
                              v_times <- v_times[v_times <= years[i]]
                              if(length(v_times) == 0) v_times <- 0
                              mu_long <- beta_true[1] + beta_true[2]*age_z_true[i] + beta_true[3]*drug[i] + beta_true[4]*v_times + b[i, 1] + b[i, 2]*v_times
                              long_list[[i]] <- data.frame(id = i, time = v_times, Y = mu_long + rALD(length(v_times), sigma_ald, current_tau))
                            }
                            df_long <- do.call(rbind, long_list)
                            df_surv <- data.frame(id = 1:n_subj, years = years, status = status, age = age, drug = drug, age_z_true = age_z_true)
                            
                            # ========================================================
                            # 2. 模拟数据分析管线：分层抽样 & 真实尺度映射
                            # ========================================================
                            train_idx <- as.numeric(caret::createDataPartition(as.factor(df_surv$status), p = 0.75, list = FALSE))
                            test_ids  <- setdiff(1:n_subj, train_idx)
                            
                            df_surv_train <- df_surv %>% filter(id %in% train_idx)
                            df_surv_test  <- df_surv %>% filter(id %in% test_ids)
                            df_long_train <- df_long %>% filter(id %in% train_idx)
                            
                            df_surv_train$age_z <- df_surv_train$age_z_true
                            df_surv_test$age_z  <- df_surv_test$age_z_true
                            
                            df_long_train$age_z <- df_surv_train$age_z[match(df_long_train$id, df_surv_train$id)]
                            df_long_train$drug  <- df_surv_train$drug[match(df_long_train$id, df_surv_train$id)]
                            
                            df_surv_train$id_jags <- 1:nrow(df_surv_train)
                            df_long_train$id_jags <- match(df_long_train$id, df_surv_train$id)
                            n_train <- nrow(df_surv_train)
                            
                            num_meas_train <- as.numeric(table(factor(df_long_train$id_jags, levels = 1:n_train)))
                            
                            Y_mat <- matrix(NA, n_train, max(num_meas_train))
                            time_mat <- matrix(0, n_train, max(num_meas_train)) 
                            
                            for(i in 1:n_train) {
                              idx <- which(df_long_train$id_jags == i)
                              if(length(idx) > 0) {
                                Y_mat[i, 1:length(idx)] <- df_long_train$Y[idx]
                                time_mat[i, 1:length(idx)] <- df_long_train$time[idx] 
                              }
                            }
                            
                            fit_lme <- try(nlme::lme(Y ~ age_z + drug + time, random = ~ time | id_jags,
                                                     data = df_long_train, control = nlme::lmeControl(opt = "optim")), silent = TRUE)
                            init_beta <- if(!inherits(fit_lme, "try-error")) as.numeric(nlme::fixef(fit_lme)) else rnorm(4, 0, 0.1)
                            
                            fit_surv <- try(survival::survreg(Surv(years, status) ~ age_z + drug, 
                                                              data = df_surv_train, dist = "weibull"), silent = TRUE)
                            if(!inherits(fit_surv, "try-error")) {
                              init_gamma <- -as.numeric(coef(fit_surv)[2:3]) / fit_surv$scale
                              init_rho <- 1 / fit_surv$scale
                              init_log_lam <- -as.numeric(coef(fit_surv)[1]) / fit_surv$scale
                            } else {
                              init_gamma <- rnorm(2, 0, 0.1); init_rho <- 1.0; init_log_lam <- log(0.01)
                            }
                            
                            inits_func <- function(chain_id) {
                              list(
                                beta = as.numeric(init_beta) + rnorm(4, 0, 0.05),
                                gamma_surv = as.numeric(init_gamma) + rnorm(2, 0, 0.05),
                                alpha = runif(1, 0.1, 0.5), 
                                log_lambda = init_log_lam + rnorm(1, 0, 0.05), 
                                rho = init_rho * exp(rnorm(1, 0, 0.05))
                              )
                            }
                            inits_list <- list(inits_func(1), inits_func(2))
                            
                            jags_data_train <- list(
                              N_subj = n_train, num_meas = num_meas_train, Y = Y_mat, time = time_mat,              
                              years = df_surv_train$years, delta = df_surv_train$status, 
                              age = df_surv_train$age_z, drug = df_surv_train$drug, tau_quant = current_tau, 
                              R.mat = matrix(c(1, 0, 0, 0.1), 2, 2),  k.wishart = 3, zeros = rep(0, n_train),
                              GK.nodes = GK.nodes, GK.weights = GK.weights
                            )
                            
                            # ========================================================
                            # 3. 模型执行与动态预测
                            # ========================================================
                            res <- tryCatch({
                              m <- jags.model("jm_ald_weibull_sim_current.jags", data = jags_data_train, inits = inits_list, n.chains = 2, n.adapt = 10000, quiet = TRUE)
                              update(m, 20000, progress.bar = "none") 
                              
                              var_names_to_monitor <- c(names(true_param_vec), "D_inv", "lambda", "rho") 
                              samples <- coda.samples(m, variable.names = var_names_to_monitor, n.iter = 10000, thin = 50)
                              post_mat_full <- as.matrix(samples) 
                              actual_P <- min(nrow(post_mat_full), target_P) 
                              post_mat <- post_mat_full[sample(1:nrow(post_mat_full), actual_P), ]
                              
                              summ <- summary(samples)
                              rhat <- tryCatch(gelman.diag(samples, multivariate = FALSE)$psrf[, 1], error = function(e) rep(NA, ncol(post_mat)))
                              
                              current_estimates <- data.frame(
                                param = rownames(summ$statistics), mean_est = summ$statistics[, "Mean"],
                                sd_est = summ$statistics[, "SD"], lower = summ$quantiles[, "2.5%"], upper = summ$quantiles[, "97.5%"], r_hat = rhat, sim_id = s
                              )
                              
                              safe_file <- sprintf("%s/cv_res_%03d.csv", folder_name, s)
                              tryCatch({ write.csv(current_estimates, file = safe_file, row.names = FALSE) }, error = function(e) {})
                              trace_to_keep <- if(s %in% c(1, 50, 100)) list(sim_id = s, samples = samples) else NULL
                              
                              all_windows_pred_list <- list() 
                              
                              for (w in 1:nrow(time_windows)) {
                                current_t <- time_windows$landmark_t[w]
                                current_s <- time_windows$horizon_s[w]
                                
                                df_surv_test_sub <- df_surv_test %>% filter(years > current_t)
                                if (nrow(df_surv_test_sub) == 0) next 
                                
                                pred_results <- data.frame(
                                  sim_id = s, window_t = current_t, window_s = current_s, id = df_surv_test_sub$id, 
                                  true_years = df_surv_test_sub$years, event = df_surv_test_sub$status, pi_pred = NA, pi_true = NA
                                )
                                
                                for (idx in 1:nrow(df_surv_test_sub)) {
                                  new_id <- df_surv_test_sub$id[idx]
                                  history_Y <- df_long %>% filter(id == new_id & time <= current_t)
                                  Y_obs <- history_Y$Y; t_obs <- history_Y$time
                                  
                                  age_i <- df_surv_test_sub$age_z[idx]; drug_i <- df_surv_test_sub$drug[idx]
                                  age_true_i <- df_surv_test_sub$age_z_true[idx]
                                  n_i <- length(Y_obs)
                                  
                                  b_true_i <- b[new_id, ]
                                  H_true_land <- calc_cum_hazard_weibull_cpp(current_t, lambda_true, gamma_shape, alpha_true, beta_true, gamma_true, c(age_true_i, drug_i), b_true_i, GK.nodes, GK.weights)
                                  H_true_horiz <- calc_cum_hazard_weibull_cpp(current_s, lambda_true, gamma_shape, alpha_true, beta_true, gamma_true, c(age_true_i, drug_i), b_true_i, GK.nodes, GK.weights)
                                  pred_results$pi_true[idx] <- exp(-(H_true_horiz - H_true_land))
                                  
                                  surv_prob_Q <- numeric(actual_P * target_Q); counter <- 1
                                  b_curr <- c(0, 0); e_curr <- rep(1, n_i)
                                  
                                  for (p in 1:actual_P) {
                                    # 💡重点防范：使用 as.numeric()[1] 提取，斩断矩阵 extent = 0 报错
                                    beta_p       <- as.numeric(post_mat[p, c("beta[1]", "beta[2]", "beta[3]", "beta[4]")])
                                    gamma_surv_p <- as.numeric(post_mat[p, c("gamma_surv[1]", "gamma_surv[2]")])
                                    alpha_p      <- as.numeric(post_mat[p, "alpha"])[1]
                                    sig_p        <- as.numeric(post_mat[p, "sigma"])[1]
                                    lambda_p     <- as.numeric(post_mat[p, "lambda"])[1]
                                    rho_p        <- as.numeric(post_mat[p, "rho"])[1]
                                    
                                    Tau_b_p <- matrix(c(post_mat[p, "D_inv[1,1]"], post_mat[p, "D_inv[2,1]"], 
                                                        post_mat[p, "D_inv[1,2]"], post_mat[p, "D_inv[2,2]"]), 2, 2)
                                    
                                    for (q_iter in 1:(target_Q + n_burn)) {
                                      if (n_i > 0) {
                                        mu_ij <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*drug_i + beta_p[4]*t_obs + b_curr[1] + b_curr[2]*t_obs
                                        gig_chi <- pmax((Y_obs - mu_ij)^2 / (k2_sq * sig_p), 1e-6)
                                        e_curr <- rgig(n = n_i, lambda = 0.5, chi = gig_chi, psi = (k1^2 + 2*k2_sq) / (k2_sq * sig_p))
                                      }
                                      
                                      calc_log_post_b <- function(b_val) {
                                        log_prior <- -0.5 * as.numeric(t(b_val) %*% Tau_b_p %*% b_val)
                                        log_lik_long <- 0
                                        if (n_i > 0) {
                                          mu_val <- beta_p[1] + beta_p[2]*age_i + beta_p[3]*drug_i + beta_p[4]*t_obs + b_val[1] + b_val[2]*t_obs
                                          log_lik_long <- sum( - (Y_obs - mu_val - k1 * e_curr)^2 / (2 * k2_sq * sig_p * e_curr) )
                                        }
                                        cum_H_landmark <- calc_cum_hazard_weibull_cpp(current_t, lambda_p, rho_p, alpha_p, beta_p, gamma_surv_p, c(age_i, drug_i), b_val, GK.nodes, GK.weights)
                                        return(log_prior + log_lik_long - cum_H_landmark)
                                      }
                                      
                                      log_post_curr <- calc_log_post_b(b_curr)
                                      b_cand <- b_curr + MASS::mvrnorm(1, mu = c(0,0), Sigma = prop_Sigma)
                                      log_post_cand <- calc_log_post_b(b_cand)

                                      # 💡重点防范：拦截 NaN/NA 导致的报错
                                      if (!is.na(log_post_cand) && !is.na(log_post_curr)) {
                                        if (log_post_cand - log_post_curr > log(runif(1))) {
                                          b_curr <- b_cand
                                        }
                                      }
                                      
                                      if (q_iter > n_burn) {
                                        H_land <- calc_cum_hazard_weibull_cpp(current_t, lambda_p, rho_p, alpha_p, beta_p, gamma_surv_p, c(age_i, drug_i), b_curr, GK.nodes, GK.weights)
                                        H_horiz <- calc_cum_hazard_weibull_cpp(current_s, lambda_p, rho_p, alpha_p, beta_p, gamma_surv_p, c(age_i, drug_i), b_curr, GK.nodes, GK.weights)
                                        surv_prob_Q[counter] <- exp(-(H_horiz - H_land))
                                        counter <- counter + 1
                                      }
                                    } 
                                  } 
                                  pred_results$pi_pred[idx] <- mean(surv_prob_Q, na.rm = TRUE)
                                }
                                all_windows_pred_list[[w]] <- pred_results
                              } 
                              
                              final_pred_results <- do.call(rbind, all_windows_pred_list)
                              
                              sim_metrics <- final_pred_results %>%
                                filter(!is.na(pi_pred)) %>%
                                filter(!(true_years <= window_s & event == 0)) %>%
                                mutate(survived_s = ifelse(true_years > window_s, 1, 0)) %>%
                                group_by(window_t, window_s) %>%
                                summarise(
                                  sim_id = s,
                                  N_Test = n(),
                                  brier_pred = mean((pi_pred - survived_s)^2),
                                  # direction="<" 强制规定：存活概率(pi_pred)越大，越对应存活标签(survived_s=1)
                                  # 避免 auto 导致的由于模型表现差而静默翻转 AUC
                                  auc_pred = as.numeric(pROC::roc(survived_s, pi_pred, direction="<", quiet=TRUE)$auc),
                                  brier_true = mean((pi_true - survived_s)^2),
                                  auc_true = as.numeric(pROC::roc(survived_s, pi_true, direction="<", quiet=TRUE)$auc),
                                  .groups = "drop"
                                )
                              
                              list(
                                estimates = current_estimates, 
                                predictions = final_pred_results,
                                metrics = sim_metrics,         
                                debug_data = list(df_long = df_long, df_surv = df_surv),
                                censor_rate = mean(df_surv_train$status == 0),
                                trace = trace_to_keep,         
                                censor_times = c_time,         
                                event_status = status          
                              )
                                  
                            }, error = function(e) {
                              cat(sprintf("\n[Worker Error] Sim %d Failed: %s\n", s, conditionMessage(e)))
                              return(NULL)
                            })
                            
                            gc() 
                            return(res)
                          }
  
  run_time <- Sys.time() - start_time
  valid_res <- Filter(Negate(is.null), results_list)
  
  if (length(valid_res) == 0) {
    cat(sprintf("\n❌ 分位数 tau = %.2f 的所有并行任务均运行失败，未生成结果。\n", current_tau))
    next
  }
  
  avg_censor_rate <- mean(sapply(valid_res, `[[`, "censor_rate"))
  all_c_times_matrix <- do.call(rbind, lapply(valid_res, `[[`, "censor_times"))
  all_status_matrix <- do.call(rbind, lapply(valid_res, `[[`, "event_status"))
  all_estimates_df <- do.call(rbind, lapply(valid_res, `[[`, "estimates"))
  all_predictions_df <- do.call(rbind, lapply(valid_res, `[[`, "predictions"))
  all_metrics_df <- do.call(rbind, lapply(valid_res, `[[`, "metrics"))
  
  rdata_filename <- sprintf("current_value_random_pred_100_multi_window_%.2f.RData", current_tau)
  save(all_estimates_df, avg_censor_rate, all_c_times_matrix, all_status_matrix, all_metrics_df, all_predictions_df, run_time, 
       file = rdata_filename)
  
  cat(sprintf("\n✅ 分位数 tau = %.2f 的执行已完成！结果已存至 %s\n", current_tau, rdata_filename))
}

stopCluster(cl)
cat("\n🎉 所有分位数 (0.25, 0.50, 0.75) 全部执行完毕！\n")