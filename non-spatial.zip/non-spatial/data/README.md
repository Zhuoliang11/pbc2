# Data

No original patient-level data or generated simulation datasets are included in this repository.

The PBC2 application scripts load `pbc2` and `pbc2.id` from the installed `JM` R package. The simulation scripts generate their analysis datasets in memory when run.
