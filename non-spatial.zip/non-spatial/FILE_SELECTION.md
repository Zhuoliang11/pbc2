# Public-file selection

## Included

- PBC2 R simulation code.
- PBC2 R application code.
- PBC2 JAGS model files.
- Documentation and ignore rules.

## Excluded

- Every HIV spatial-analysis R script.
- Every Stan file and every R script containing embedded Stan source.
- HIV original data and spatial boundary files.
- All generated simulation datasets and result files.
- Posterior objects, MCMC output, CSV results, figures, PDFs, and compiled executables.
- Duplicate, temporary, cluster-specific, and historical HIV scripts.

The original source folders were not modified.
